This directory contains sources of program AntiDupl-2.4.2 for C++Builder-6.
Yermalayeu Ihar, Minsk, Belarus, 2002-2009.


