/***********************************************************************
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru

Wrapper of GDI+ bitmap object for C++Builder (for loading of image).
Warning! For properly work need
Defines: STRICT=1; INITGUID=1;
Libs: GDIplus.lib
************************************************************************/
#ifndef __GDIplusWrapper_h__
#define __GDIplusWrapper_h__

#include <vcl.h>
//-----------------------------------------------------------------------
namespace Gdiplus
{
 class Bitmap;
};
//-----------------------------------------------------------------------
class TGDIplus // Need for initialization of GDI+.
{
private:
 ULONG_PTR m_GDIplusToken;
public:
 TGDIplus(void);
 ~TGDIplus(void);
};
//---------------class TGDIplusImage:------------------------------------
class TGDIplusImage
{
public:
 enum FORMAT
 {
  NON = 0, 
  BMP = 1,
  GIF = 2,
  JPG = 3,
  PNG = 4,
  TIF = 5
 };
private:
 Gdiplus::Bitmap *m_pBitmap;
public:
 TGDIplusImage(void);
 ~TGDIplusImage(void);
 bool Load(const AnsiString &sFileName);
 bool GetBitmap(Graphics::TBitmap *pBitmap) const;
 bool GetThumbnail(int nWidth, int nHeight, Graphics::TBitmap *pBitmap) const;
 FORMAT GetFormat(void) const;
 int Height(void) const;
 int Width(void) const;
};
//-----------------------------------------------------------------------
#endif // __GDIplusWrapper_h__





