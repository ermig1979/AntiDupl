/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
#ifndef __SearchImageStruct_h__
#define __SearchImageStruct_h__

#include "Config.h"
#include <vcl.h>
#include "GDIplusWrapper.h"
#include <stdio.h>

//------------------------------------------------------------------------------
struct TFileInf
{
 AnsiString m_sFileName;
 int m_nFileSize;
 int m_nFileTime;

 TFileInf& operator=(const TFileInf& a);

 bool operator==(const TFileInf &a) const;
 bool operator!=(const TFileInf &a) const {return !(*this == a);};
 bool operator>(const TFileInf &a) const;
 bool operator<(const TFileInf &a) const;

 bool Load(FILE* in);
 bool Save(FILE* out) const;

 TFileInf(void) : m_nFileSize(0), m_nFileTime(0) {};
 TFileInf(const TFileInf& a){*this = a;};
 ~TFileInf(void) {};
};
//------------------------------------------------------------------------------
struct TImageInf : public TFileInf
{
 int m_nImageHeight;
 int m_nImageWidth;
 TGDIplusImage::FORMAT m_eImageFormat;

 TImageInf& operator=(const TImageInf& a);

 TImageInf(void) : m_eImageFormat(TGDIplusImage::NON),
  m_nImageHeight(0), m_nImageWidth(0){};
 TImageInf(const TImageInf& a){*this = a;};
 ~TImageInf(void){};
};
//------------------------------------------------------------------------------
struct TCollectedData : public TImageInf
{
 void *m_pKey; // Pointer to struct of key data (in simple case it is 2D array);
 int m_nSize;  // Size of struct of key data;
 int m_nRatio; // Ratio between height and width of image;

 TCollectedData& operator=(const TCollectedData& a);

 TCollectedData(int nSize = PIXELS_SIZE*PIXELS_SIZE);
 TCollectedData(const TCollectedData& a);
 ~TCollectedData(void);
};
//------------------------------------------------------------------------------
struct TSearchResult
{
 enum TYPE
 {
  UNDEF = 0,
  DEFECT = 1,
  EQUAL = 2
 };

 TSearchResult(void):m_eType(UNDEF) {};
 TSearchResult(const TSearchResult& a) {*this = a;};
 ~TSearchResult(void){};
 
 TSearchResult& operator=(const TSearchResult& a);

 TYPE m_eType;
 TImageInf m_Left;
 TImageInf m_Right;
};
//------------------------------------------------------------------------------
struct TStatistic
{
 int m_nScanedFoldersNumber;
 int m_nSearchedImagesNumber;
 int m_nScanedImagesNumber;
 int m_nDeletedImagesNumber;
 int m_nDeletedImagesSize;
 int m_nResultsNumber;

 TStatistic& operator= (const TStatistic& s);
 void Clear(void);

 TStatistic(void) {Clear();};
 TStatistic(const TStatistic& s) {*this = s;};
 ~TStatistic(void) {};
 };
//------------------------------------------------------------------------------
#endif// __SearchImageStruct_h__

 