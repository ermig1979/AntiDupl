/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
//---------------------------------------------------------------------------

#ifndef OptionsDialogUnitH
#define OptionsDialogUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TOptions;
//---------------------------------------------------------------------------
class TOptionsDialog : public TForm
{
__published:	// IDE-managed Components
        TButton *OK;
        TPageControl *PageControl;
        TButton *Cancel;
        TTabSheet *GeneralTab;
        TTabSheet *ComparisonTab;
        TButton *Default;
  TRadioGroup *LanguageRadioGrop;
  TRadioButton *EnglishLanguage;
  TRadioButton *RussianLanguage;
  TCheckBox *SubDir;
  TCheckBox *RecBin;
  TGroupBox *GroupBox1;
  TComboBox *CompareOderComboBox;
  TCheckBox *SizeControl;
  TCheckBox *FullPicture;
  TCheckBox *AutoDeleteEqual;
  TCheckBox *CheckOnEquality;
  TLabel *CompareOderLabel;
  TCheckBox *FormatControl;
  TTabSheet *OtherTab;
  TGroupBox *FormatGroupBox;
  TCheckBox *SearchJPG;
  TCheckBox *SearchBMP;
  TCheckBox *SearchGIF;
  TCheckBox *SearchPNG;
  TCheckBox *SearchTIF;
  TGroupBox *GroupBox2;
  TCheckBox *AutoDeleteDefect;
  TCheckBox *CheckOnDefect;
  TCheckBox *QueryDuringSearch;
  TCheckBox *MistakeDataBaseEnabledCheckBox;
  TButton *ClearMistakeDataBaseButton;
  TGroupBox *MistakesGroupBox;
        void __fastcall OKClick(TObject *Sender);
        void __fastcall CancelClick(TObject *Sender);
        void __fastcall DefaultClick(TObject *Sender);
  void __fastcall RussianLanguageClick(TObject *Sender);
  void __fastcall EnglishLanguageClick(TObject *Sender);
  void __fastcall SubDirClick(TObject *Sender);
  void __fastcall RecBinClick(TObject *Sender);
  void __fastcall AutoDeleteDefectClick(TObject *Sender);
  void __fastcall CheckOnDefectClick(TObject *Sender);
  void __fastcall CheckOnEqualityClick(TObject *Sender);
  void __fastcall SizeControlClick(TObject *Sender);
  void __fastcall FullPictureClick(TObject *Sender);
  void __fastcall AutoDeleteEqualClick(TObject *Sender);
  void __fastcall CompareOderComboBoxChange(TObject *Sender);
  void __fastcall FormatControlClick(TObject *Sender);
  void __fastcall SearchJPGClick(TObject *Sender);
  void __fastcall SearchBMPClick(TObject *Sender);
  void __fastcall SearchGIFClick(TObject *Sender);
  void __fastcall SearchPNGClick(TObject *Sender);
  void __fastcall SearchTIFClick(TObject *Sender);
  void __fastcall QueryDuringSearchClick(TObject *Sender);
  void __fastcall MistakeDataBaseEnabledCheckBoxClick(TObject *Sender);
  void __fastcall ClearMistakeDataBaseButtonClick(TObject *Sender);
private:	// User declarations
				TOptions *m_pOptions;
        bool m_bResult;

        void __fastcall SetOptions(void);
public:		// User declarations
        __fastcall TOptionsDialog(TComponent* Owner);
        __fastcall ~TOptionsDialog(void);

        void __fastcall Execute(TOptions *pOptions);
};
//---------------------------------------------------------------------------
extern PACKAGE TOptionsDialog *OptionsDialog;
//---------------------------------------------------------------------------
#endif
