/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
//---------------------------------------------------------------------------
#ifndef CompareDialogUnit2H
#define CompareDialogUnit2H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TOptions;
class TImageInf;
//---------------------------------------------------------------------------
class TCompareDialog2 : public TForm
{
__published:	// IDE-managed Components
  TBevel *RightBevel;
  TButton *RightDeleteButton;
  TButton *NextButton;
  TButton *StopButton;
  TCheckBox *QueryDuringSearch;
  TBevel *LeftBevel;
  TButton *LeftDeleteButton;
  TImage *RightImage;
  TImage *LeftImage;
  TLabel *RightFileNameLabel;
  TLabel *RightFileSizeLabel;
  TLabel *RightImageSizeLabel;
  TLabel *LeftFileNameLabel;
  TLabel *LeftFileSizeLabel;
  TLabel *LeftImageSizeLabel;
  TButton *DeleteBothButton;
  TButton *RightMoveButton;
  TButton *LeftMoveButton;
  TPopupMenu *LeftPopupMenu;
  TPopupMenu *RightPopupMenu;
  TMenuItem *CopyPathLeftPopupMenuItem;
  TMenuItem *OpenPictureLeftPopupMenuItem;
  TMenuItem *CopyPathRightPopupMenuItem;
  TMenuItem *OpenPictureRightPopupMenuItem;
  TButton *MistakeButton;
  void __fastcall NextButtonClick(TObject *Sender);
  void __fastcall StopButtonClick(TObject *Sender);
  void __fastcall LeftDeleteButtonClick(TObject *Sender);
  void __fastcall RightDeleteButtonClick(TObject *Sender);
  void __fastcall FormResize(TObject *Sender);
  void __fastcall FormKeyUp(TObject *Sender, WORD &Key, TShiftState Shift);
  void __fastcall DeleteBothButtonClick(TObject *Sender);
  void __fastcall LeftMoveButtonClick(TObject *Sender);
  void __fastcall RightMoveButtonClick(TObject *Sender);
  void __fastcall CopyPathLeftPopupMenuItemClick(TObject *Sender);
  void __fastcall OpenPictureLeftPopupMenuItemClick(TObject *Sender);
  void __fastcall CopyPathRightPopupMenuItemClick(TObject *Sender);
  void __fastcall OpenPictureRightPopupMenuItemClick(TObject *Sender);
  void __fastcall LeftImageDblClick(TObject *Sender);
  void __fastcall RightImageDblClick(TObject *Sender);
  void __fastcall MistakeButtonClick(TObject *Sender);
public:
  enum EResult
  {
   NEXT = 0,
   STOP = 1,
   LEFTDEL = 2,
   RIGHTDEL = 3,
   LEFTMOVE = 4,
   RIGHTMOVE = 6,
   DELETEBOTH = 7,
   MISTAKE = 8
  };
private:	// User declarations
  EResult m_eResult;
  Graphics::TBitmap *m_pLeftBitmap;
  Graphics::TBitmap *m_pRightBitmap;
  TOptions *m_pOptions;
public:		// User declarations
  EResult Show(TOptions *pOptions, TImageInf *pLeftData, TImageInf *pRightData);
  __fastcall TCompareDialog2(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TCompareDialog2 *CompareDialog2;
//---------------------------------------------------------------------------
#endif
