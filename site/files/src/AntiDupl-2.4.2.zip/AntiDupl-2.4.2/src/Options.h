/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
#ifndef __Options_h__
#define __Options_h__

#include <SysUtils.hpp>
#include <vector>

//---------------------------------------------------------------------------
const bool Default_AutoDeleteDefect = false;
const bool Default_AutoDeleteEqual = false;
const bool Default_CheckOnDefect = true;
const bool Default_CheckOnEquality = true;
const int Default_CompareOder = 2;
const int Maximal_CompareOder = 4;
const bool Default_DeleteToRecycleBin = true;
const bool Default_SizeControl = false;
const bool Default_FullPicture = false;
const bool Default_SubDirectories = true;
const bool Default_QueryDuringSearch = true;
const AnsiString Default_Language = "English";

const bool Default_FormatControl = false;
const bool Default_SearchJPG = true;
const bool Default_SearchBMP = true;
const bool Default_SearchGIF = true;
const bool Default_SearchPNG = true;
const bool Default_SearchTIF = true;

const int Default_DeleteDialogHeight = 330;
const int Default_DeleteDialogWidth = 300;
const int Default_CompareDialogHeight = 330;
const int Default_CompareDialogWidth = 550;
const bool Default_ShowSpeedButtons = true;
const bool Default_ShowStatusBar = true;

const bool Default_MistakeDataBaseEnabled = true;
//---------------------------------------------------------------------------
class TOptions
{
public:

  TOptions(void);
  TOptions(AnsiString FileName);
  TOptions(const TOptions &Options);
  ~TOptions(void);

  TOptions& operator=(const TOptions &Options);
  void Default(void);
  bool Load(AnsiString FileName);
  bool Save(AnsiString FileName);

// Data:
  bool m_bAutoDeleteDefect;
  bool m_bAutoDeleteEqual;
  bool m_bCheckOnDefect;
  bool m_bCheckOnEquality;
  int m_nCompareOder;
  bool m_bDeleteToRecycleBin;
  bool m_bSizeControl;
  bool m_bFullPicture;
  bool m_bSubDirectories;
  bool m_bQueryDuringSearch;
  AnsiString m_sLanguage;
  AnsiString m_sDirectoryName;

  bool m_bFormatControl;
  bool m_bSearchJPG;
  bool m_bSearchBMP;
  bool m_bSearchGIF;
  bool m_bSearchPNG;
  bool m_bSearchTIF;

  int m_nDeleteDialogHeight;
  int m_nDeleteDialogWidth;
  int m_nCompareDialogHeight;
  int m_nCompareDialogWidth;
  bool m_bShowSpeedButtons;
  bool m_bShowStatusBar;

  bool m_bMistakeDataBaseEnabled;
};
//---------------------------------------------------------------------------
class TStringStorage
{
 std::vector<AnsiString> m_sStrings;
 AnsiString m_sFileName;

public:
 TStringStorage(const AnsiString &sFileName);
 ~TStringStorage(void) {};
 
 bool Load(const AnsiString &sLanguage);
 const AnsiString& Get(int N) const;
};
//---------------------------------------------------------------------------
extern TStringStorage *g_pStr;
//---------------------------------------------------------------------------
#endif //__Options_h__




