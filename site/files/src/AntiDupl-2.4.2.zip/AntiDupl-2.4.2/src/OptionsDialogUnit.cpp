/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "OptionsDialogUnit.h"
#include "Options.h"
#include "MistakeDataBase.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TOptionsDialog *OptionsDialog;
//---------------------------------------------------------------------------
__fastcall TOptionsDialog::TOptionsDialog(TComponent* Owner)
        : TForm(Owner)
{
  m_pOptions = new TOptions();
}
//---------------------------------------------------------------------------
__fastcall TOptionsDialog::~TOptionsDialog(void)
{
  delete m_pOptions;
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::OKClick(TObject *Sender)
{
  m_bResult = true;
  Close();
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::CancelClick(TObject *Sender)
{
  m_bResult = false;
  Close();
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::DefaultClick(TObject *Sender)
{
  m_pOptions->Default();
  SetOptions();
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::Execute(TOptions *pOptions)
{
  (*m_pOptions) = (*pOptions);
  SetOptions();
  ShowModal();
  if(m_bResult)
    (*pOptions) = (*m_pOptions);
};
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::SetOptions(void)
{
  if(m_pOptions->m_sLanguage == "Russian")
  {
    EnglishLanguage->Checked = false;
    RussianLanguage->Checked = true;
    CompareOderComboBox->Items->Text = "���\r\n���������\r\n�������\r\n�������\r\n����������";
  }
  else if(m_pOptions->m_sLanguage == "English")
  {
    EnglishLanguage->Checked = true;
    RussianLanguage->Checked = false;
    CompareOderComboBox->Items->Text = "None\r\nSmall\r\nNormal\r\nBig\r\nVery big";
  }
  Caption = g_pStr->Get(4);
  EnglishLanguage->Caption = g_pStr->Get(26);
  RussianLanguage->Caption = g_pStr->Get(27);
  LanguageRadioGrop->Caption = g_pStr->Get(28);
  SubDir->Caption = g_pStr->Get(29);
  RecBin->Caption = g_pStr->Get(30);
  QueryDuringSearch->Caption = g_pStr->Get(31);
  GeneralTab->Caption = g_pStr->Get(32);
  OtherTab->Caption = g_pStr->Get(33);
  FormatGroupBox->Caption = g_pStr->Get(34);
  CheckOnDefect->Caption = g_pStr->Get(35);
  AutoDeleteDefect->Caption = g_pStr->Get(36);
  ComparisonTab->Caption = g_pStr->Get(37);
  CompareOderLabel->Caption = g_pStr->Get(38);
  CheckOnEquality->Caption = g_pStr->Get(39);
  FullPicture->Caption = g_pStr->Get(40);
  SizeControl->Caption = g_pStr->Get(41);
  FormatControl->Caption = g_pStr->Get(42);
  AutoDeleteEqual->Caption = g_pStr->Get(43);
  Default->Caption = g_pStr->Get(66);
  Cancel->Caption = g_pStr->Get(65);
  MistakeDataBaseEnabledCheckBox->Caption = g_pStr->Get(71);
  ClearMistakeDataBaseButton->Caption = g_pStr->Get(72);
  ClearMistakeDataBaseButton->Hint = g_pStr->Get(73);
  MistakesGroupBox->Caption = g_pStr->Get(78);

  SubDir->Checked = m_pOptions->m_bSubDirectories;
  RecBin->Checked = m_pOptions->m_bDeleteToRecycleBin;
  QueryDuringSearch->Checked = m_pOptions->m_bQueryDuringSearch;
  MistakeDataBaseEnabledCheckBox->Checked = m_pOptions->m_bMistakeDataBaseEnabled;

  CheckOnDefect->Checked = m_pOptions->m_bCheckOnDefect;
  AutoDeleteDefect->Checked = m_pOptions->m_bAutoDeleteDefect;
  AutoDeleteDefect->Enabled = CheckOnDefect->Checked;
  SearchJPG->Checked = m_pOptions->m_bSearchJPG;
  SearchBMP->Checked = m_pOptions->m_bSearchBMP;
  SearchGIF->Checked = m_pOptions->m_bSearchGIF;
  SearchPNG->Checked = m_pOptions->m_bSearchPNG;
  SearchTIF->Checked = m_pOptions->m_bSearchTIF;

  CheckOnEquality->Checked = m_pOptions->m_bCheckOnEquality;
  FullPicture->Checked = m_pOptions->m_bFullPicture;
  FullPicture->Enabled = CheckOnEquality->Checked;
  SizeControl->Checked = m_pOptions->m_bSizeControl;
  SizeControl->Enabled = CheckOnEquality->Checked;
  FormatControl->Checked = m_pOptions->m_bFormatControl;
  FormatControl->Enabled = CheckOnEquality->Checked;
  AutoDeleteEqual->Checked = m_pOptions->m_bAutoDeleteEqual;
  AutoDeleteEqual->Enabled = CheckOnEquality->Checked;
  CompareOderLabel->Enabled = CheckOnEquality->Checked;
  CompareOderComboBox->ItemIndex = m_pOptions->m_nCompareOder;
  CompareOderComboBox->Enabled = CheckOnEquality->Checked;
 };
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::RussianLanguageClick(TObject *Sender)
{
  m_pOptions->m_sLanguage = "Russian";
  g_pStr->Load(m_pOptions->m_sLanguage);
  SetOptions();
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::EnglishLanguageClick(TObject *Sender)
{
  m_pOptions->m_sLanguage = "English";
  g_pStr->Load(m_pOptions->m_sLanguage);
  SetOptions();
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::SubDirClick(TObject *Sender)
{
  m_pOptions->m_bSubDirectories = SubDir->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::RecBinClick(TObject *Sender)
{
  m_pOptions->m_bDeleteToRecycleBin = RecBin->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::AutoDeleteDefectClick(TObject *Sender)
{
  m_pOptions->m_bAutoDeleteDefect = AutoDeleteDefect->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::CheckOnDefectClick(TObject *Sender)
{
  m_pOptions->m_bCheckOnDefect = CheckOnDefect->Checked;
  AutoDeleteDefect->Enabled = CheckOnDefect->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::CheckOnEqualityClick(TObject *Sender)
{
  m_pOptions->m_bCheckOnEquality = CheckOnEquality->Checked;
  FullPicture->Enabled = CheckOnEquality->Checked;
  SizeControl->Enabled = CheckOnEquality->Checked;
  FormatControl->Enabled = CheckOnEquality->Checked;
  AutoDeleteEqual->Enabled = CheckOnEquality->Checked;
  CompareOderLabel->Enabled = CheckOnEquality->Checked;
  CompareOderComboBox->Enabled = CheckOnEquality->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::SizeControlClick(TObject *Sender)
{
  m_pOptions->m_bSizeControl = SizeControl->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::FullPictureClick(TObject *Sender)
{
  m_pOptions->m_bFullPicture = FullPicture->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::AutoDeleteEqualClick(TObject *Sender)
{
  m_pOptions->m_bAutoDeleteEqual = AutoDeleteEqual->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::CompareOderComboBoxChange(TObject *Sender)
{
  m_pOptions->m_nCompareOder = CompareOderComboBox->ItemIndex;
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::FormatControlClick(TObject *Sender)
{
  m_pOptions->m_bFormatControl = FormatControl->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::SearchJPGClick(TObject *Sender)
{
  m_pOptions->m_bSearchJPG = SearchJPG->Checked;
}
//---------------------------------------------------------------------------

void __fastcall TOptionsDialog::SearchBMPClick(TObject *Sender)
{
  m_pOptions->m_bSearchBMP = SearchBMP->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::SearchGIFClick(TObject *Sender)
{
  m_pOptions->m_bSearchGIF = SearchGIF->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::SearchPNGClick(TObject *Sender)
{
  m_pOptions->m_bSearchPNG = SearchPNG->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::SearchTIFClick(TObject *Sender)
{
  m_pOptions->m_bSearchTIF = SearchTIF->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::QueryDuringSearchClick(TObject *Sender)
{
  m_pOptions->m_bQueryDuringSearch = QueryDuringSearch->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::MistakeDataBaseEnabledCheckBoxClick(
      TObject *Sender)
{
  m_pOptions->m_bMistakeDataBaseEnabled = MistakeDataBaseEnabledCheckBox->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TOptionsDialog::ClearMistakeDataBaseButtonClick(
      TObject *Sender)
{
  if (g_pMistakeDataBase)
    g_pMistakeDataBase->Clear();
}
//---------------------------------------------------------------------------

