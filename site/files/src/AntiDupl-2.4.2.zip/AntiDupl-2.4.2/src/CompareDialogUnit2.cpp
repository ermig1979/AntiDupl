/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
//---------------------------------------------------------------------------
#include <vcl.h>
#include <vcl\Clipbrd.hpp>
#pragma hdrstop

#include "CompareDialogUnit2.h"
#include "Utils.h"
#include "SearchImage.h"
#include "Options.h"
#include "GDIplusWrapper.h"
#include "MainWindowUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TCompareDialog2 *CompareDialog2;
//---------------------------------------------------------------------------
__fastcall TCompareDialog2::TCompareDialog2(TComponent* Owner)
  : TForm(Owner)
{
 m_eResult = STOP;
 DoubleBuffered = true;
}
//---------------------------------------------------------------------------
void __fastcall TCompareDialog2::NextButtonClick(TObject *Sender)
{
 m_eResult = NEXT;
 Close();
}
//---------------------------------------------------------------------------
void __fastcall TCompareDialog2::StopButtonClick(TObject *Sender)
{
 m_eResult = STOP;
 Close();
}
//---------------------------------------------------------------------------
void __fastcall TCompareDialog2::LeftDeleteButtonClick(TObject *Sender)
{
 m_eResult = LEFTDEL;
 Close();
}
//---------------------------------------------------------------------------
void __fastcall TCompareDialog2::RightDeleteButtonClick(TObject *Sender)
{
 m_eResult = RIGHTDEL;
 Close();
}
//---------------------------------------------------------------------------
TCompareDialog2::EResult TCompareDialog2::Show(TOptions *pOptions, TImageInf *pLeftData, TImageInf *pRightData)
{
 m_pOptions = pOptions;
 MainWindow->SetProgramState(PS_FOUND);
 QueryDuringSearch->Visible = pOptions->m_bQueryDuringSearch;
 QueryDuringSearch->Checked = pOptions->m_bQueryDuringSearch;
 MistakeButton->Visible = pOptions->m_bMistakeDataBaseEnabled;

 StopButton->Caption = g_pStr->Get(10);
 StopButton->Hint = g_pStr->Get(59);
 NextButton->Caption = g_pStr->Get(8);
 NextButton->Hint = g_pStr->Get(60);
 DeleteBothButton->Caption = g_pStr->Get(67);
 DeleteBothButton->Hint = g_pStr->Get(68);
 LeftMoveButton->Hint = g_pStr->Get(69);
 RightMoveButton->Hint = g_pStr->Get(70);
 Caption = g_pStr->Get(45);
 QueryDuringSearch->Caption = g_pStr->Get(31);
 LeftDeleteButton->Hint = g_pStr->Get(62);
 RightDeleteButton->Hint = g_pStr->Get(63);
 CopyPathRightPopupMenuItem->Caption = g_pStr->Get(74);
 CopyPathLeftPopupMenuItem->Caption = g_pStr->Get(74);
 OpenPictureRightPopupMenuItem->Caption = g_pStr->Get(75);
 OpenPictureLeftPopupMenuItem->Caption = g_pStr->Get(75);
 MistakeButton->Caption = g_pStr->Get(76);
 MistakeButton->Hint = g_pStr->Get(77);

 m_eResult = STOP;
 TGDIplusImage *pLeftImage = new TGDIplusImage();
 TGDIplusImage *pRightImage = new TGDIplusImage();
 if(pLeftImage->Load(pLeftData->m_sFileName))
 {
  m_pLeftBitmap = new Graphics::TBitmap();
  pLeftImage->GetBitmap(m_pLeftBitmap);
  LeftFileSizeLabel->Caption = IntToGroupedString(pLeftData->m_nFileSize) + " B";
  LeftImageSizeLabel->Caption = IntToStr(pLeftData->m_nImageWidth) + "x" + IntToStr(pLeftData->m_nImageHeight);
  AnsiString sTemp = pLeftData->m_sFileName;
  sTemp.Delete(1, pOptions->m_sDirectoryName.Length());
  LeftFileNameLabel->Caption = "..." + sTemp;
  LeftFileNameLabel->Hint = pLeftData->m_sFileName;
  if(pRightImage->Load(pRightData->m_sFileName))
  {
   m_pRightBitmap = new Graphics::TBitmap();
   pRightImage->GetBitmap(m_pRightBitmap);
   RightFileSizeLabel->Caption = IntToGroupedString(pRightData->m_nFileSize) + " B";
   RightImageSizeLabel->Caption = IntToStr(pRightData->m_nImageWidth) + "x" + IntToStr(pRightData->m_nImageHeight);
   sTemp = pRightData->m_sFileName;
   sTemp.Delete(1, pOptions->m_sDirectoryName.Length());
   RightFileNameLabel->Caption = "..." + sTemp;
   RightFileNameLabel->Hint = pRightData->m_sFileName;
   Height = pOptions->m_nCompareDialogHeight;
   Width = pOptions->m_nCompareDialogWidth;
   StretchBitmapToImage(LeftImage, m_pLeftBitmap);
   StretchBitmapToImage(RightImage, m_pRightBitmap);
   TColor TempColor = LeftFileSizeLabel->Font->Color;
   if(pLeftData->m_nFileSize < pRightData->m_nFileSize)
    LeftFileSizeLabel->Font->Color = clRed;
   if(pLeftData->m_nFileSize > pRightData->m_nFileSize)
    RightFileSizeLabel->Font->Color = clRed;
   if(pLeftData->m_nImageWidth*pLeftData->m_nImageHeight < pRightData->m_nImageWidth*pRightData->m_nImageHeight)
    LeftImageSizeLabel->Font->Color = clRed;
   if(pLeftData->m_nImageWidth*pLeftData->m_nImageHeight > pRightData->m_nImageWidth*pRightData->m_nImageHeight)
    RightImageSizeLabel->Font->Color = clRed;
   ShowModal();
   LeftFileSizeLabel->Font->Color = TempColor;
   RightFileSizeLabel->Font->Color = TempColor;
   LeftImageSizeLabel->Font->Color = TempColor;
   RightImageSizeLabel->Font->Color = TempColor;
   pOptions->m_bQueryDuringSearch = QueryDuringSearch->Checked;
   pOptions->m_nCompareDialogHeight = Height;
   pOptions->m_nCompareDialogWidth = Width;
   delete m_pRightBitmap;
  };
  delete m_pLeftBitmap;
 };
 MainWindow->SetProgramState(PS_RUN);
 delete pLeftImage;
 delete pRightImage;
 return m_eResult;
};
//---------------------------------------------------------------------------
void __fastcall TCompareDialog2::FormResize(TObject *Sender)
{
 const int ImageBorder = 4;
 int nWidth = ClientWidth/2 - 2*ImageBorder - 1;

 StopButton->Top = ClientHeight - ImageBorder - StopButton->Height;
 StopButton->Left = ClientWidth - ImageBorder - StopButton->Width;

 NextButton->Top = ClientHeight - ImageBorder - NextButton->Height;
 NextButton->Left = ClientWidth/2 - NextButton->Width - ImageBorder;

 DeleteBothButton->Top = ClientHeight - ImageBorder - DeleteBothButton->Height;
 DeleteBothButton->Left = ClientWidth/2 + ImageBorder;

 MistakeButton->Top = ClientHeight - ImageBorder - MistakeButton->Height;
 MistakeButton->Left = (DeleteBothButton->Left + DeleteBothButton->Width + StopButton->Left)/2 - MistakeButton->Width/2;

 QueryDuringSearch->Top = ClientHeight - ImageBorder - QueryDuringSearch->Height;
 QueryDuringSearch->Left = ImageBorder;
 QueryDuringSearch->Width = NextButton->Left - ImageBorder*2;

 LeftBevel->Top = 0;
 LeftBevel->Left = 0;
 LeftBevel->Height = StopButton->Top - ImageBorder;
 LeftBevel->Width = ClientWidth/2;

 LeftDeleteButton->Left = ClientWidth/2 - ImageBorder - LeftDeleteButton->Width;
 LeftDeleteButton->Top = LeftBevel->Height - ImageBorder - LeftDeleteButton->Height;

 LeftMoveButton->Left = LeftDeleteButton->Left - ImageBorder*5 - LeftMoveButton->Width;
 LeftMoveButton->Top = LeftBevel->Height - ImageBorder - LeftMoveButton->Height;

 LeftImageSizeLabel->Left = ImageBorder;
 LeftImageSizeLabel->Width = nWidth;
 LeftImageSizeLabel->Top = LeftDeleteButton->Top - LeftImageSizeLabel->Height - ImageBorder/2;

 LeftFileSizeLabel->Left = ImageBorder;
 LeftFileSizeLabel->Width = nWidth;
 LeftFileSizeLabel->Top = LeftImageSizeLabel->Top - LeftFileSizeLabel->Height - ImageBorder/2;

 LeftFileNameLabel->Left = ImageBorder;
 LeftFileNameLabel->Width = nWidth;
 LeftFileNameLabel->Top = LeftFileSizeLabel->Top - LeftFileNameLabel->Height - ImageBorder/2;

 LeftImage->Top = ImageBorder;
 LeftImage->Left = ImageBorder;
 LeftImage->Width = nWidth;
 LeftImage->Picture->Bitmap->Width = nWidth;
 LeftImage->Height = LeftFileNameLabel->Top - 2*ImageBorder;
 LeftImage->Picture->Bitmap->Height = LeftFileNameLabel->Top - 2*ImageBorder;
 StretchBitmapToImage(LeftImage, m_pLeftBitmap);

 RightBevel->Top = 0;
 RightBevel->Left = ClientWidth/2;
 RightBevel->Height = StopButton->Top - ImageBorder;
 RightBevel->Width = ClientWidth/2;

 RightDeleteButton->Left = ClientWidth/2 + ImageBorder;
 RightDeleteButton->Top = RightBevel->Height - ImageBorder - RightDeleteButton->Height;

 RightMoveButton->Left = RightDeleteButton->Left + RightDeleteButton->Width + ImageBorder*5;
 RightMoveButton->Top = RightBevel->Height - ImageBorder - RightMoveButton->Height;

 RightImageSizeLabel->Left = ClientWidth/2 + ImageBorder;
 RightImageSizeLabel->Width = nWidth;
 RightImageSizeLabel->Top = RightDeleteButton->Top - RightImageSizeLabel->Height - ImageBorder/2;

 RightFileSizeLabel->Left = ClientWidth/2 + ImageBorder;
 RightFileSizeLabel->Width = nWidth;
 RightFileSizeLabel->Top = RightImageSizeLabel->Top - RightFileSizeLabel->Height - ImageBorder/2;

 RightFileNameLabel->Left = ClientWidth/2 + ImageBorder;
 RightFileNameLabel->Width = nWidth;
 RightFileNameLabel->Top = RightFileSizeLabel->Top - RightFileNameLabel->Height - ImageBorder/2;

 RightImage->Top = ImageBorder;
 RightImage->Left = ClientWidth/2 + ImageBorder;
 RightImage->Width = nWidth;
 RightImage->Picture->Bitmap->Width = nWidth;
 RightImage->Height = RightFileNameLabel->Top - 2*ImageBorder;
 RightImage->Picture->Bitmap->Height = RightFileNameLabel->Top - 2*ImageBorder;
 StretchBitmapToImage(RightImage, m_pRightBitmap);
}
//---------------------------------------------------------------------------
void __fastcall TCompareDialog2::FormKeyUp(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
 switch(Key)
 {
  case VK_PAUSE:
   m_eResult = STOP;
   Close();
   break;
  case VK_SHIFT:
   m_eResult = NEXT;
   Close();
   break;
  case VK_DELETE:
   m_eResult = LEFTDEL;
   Close();
   break;
  case VK_END:
   m_eResult = RIGHTDEL;
   Close();
   break;
  case VK_INSERT:
   m_eResult = RIGHTMOVE;
   Close();
   break;
  case VK_HOME:
   m_eResult = LEFTMOVE;
   Close();
   break;
  case VK_NEXT:
   m_eResult = DELETEBOTH;
   Close();
   break;
  case VK_PRIOR:
   if(m_pOptions->m_bMistakeDataBaseEnabled)
   {
    m_eResult = MISTAKE;
    Close();
   }
   break;
  }
}
//---------------------------------------------------------------------------
void __fastcall TCompareDialog2::DeleteBothButtonClick(TObject *Sender)
{
 m_eResult = DELETEBOTH;
 Close();
}
//---------------------------------------------------------------------------
void __fastcall TCompareDialog2::LeftMoveButtonClick(TObject *Sender)
{
 m_eResult = RIGHTMOVE;
 Close();
}
//---------------------------------------------------------------------------
void __fastcall TCompareDialog2::RightMoveButtonClick(TObject *Sender)
{
 m_eResult = LEFTMOVE;
 Close();
}
//---------------------------------------------------------------------------
void __fastcall TCompareDialog2::CopyPathLeftPopupMenuItemClick(
      TObject *Sender)
{
 Clipboard()->AsText = LeftFileNameLabel->Hint.c_str();
}
//---------------------------------------------------------------------------
void __fastcall TCompareDialog2::OpenPictureLeftPopupMenuItemClick(
      TObject *Sender)
{
 ShellExecute(Handle, "open", LeftFileNameLabel->Hint.c_str(), NULL, NULL, SW_SHOWNORMAL);
}
//---------------------------------------------------------------------------
void __fastcall TCompareDialog2::CopyPathRightPopupMenuItemClick(
      TObject *Sender)
{
 Clipboard()->AsText = RightFileNameLabel->Hint.c_str();
}
//---------------------------------------------------------------------------
void __fastcall TCompareDialog2::OpenPictureRightPopupMenuItemClick(
      TObject *Sender)
{
 ShellExecute(Handle, "open", RightFileNameLabel->Hint.c_str(), NULL, NULL, SW_SHOWNORMAL);
}
//---------------------------------------------------------------------------
void __fastcall TCompareDialog2::LeftImageDblClick(TObject *Sender)
{
 ShellExecute(Handle, "open", LeftFileNameLabel->Hint.c_str(), NULL, NULL, SW_SHOWNORMAL);
}
//---------------------------------------------------------------------------
void __fastcall TCompareDialog2::RightImageDblClick(TObject *Sender)
{
 ShellExecute(Handle, "open", RightFileNameLabel->Hint.c_str(), NULL, NULL, SW_SHOWNORMAL);
}
//---------------------------------------------------------------------------
void __fastcall TCompareDialog2::MistakeButtonClick(TObject *Sender)
{
 m_eResult = MISTAKE;
 Close();
}
//---------------------------------------------------------------------------

