/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
#include <vcl.h>
#include "GDIplusWrapper.h"
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("MainWindowUnit.cpp", MainWindow);
USEFORM("OptionsDialogUnit.cpp", OptionsDialog);
USEFORM("CompareDialogUnit2.cpp", CompareDialog2);
USEFORM("DeleteDialogUnit2.cpp", DeleteDialog2);
USEFORM("AboutDialogUnit.cpp", AboutDialog);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
 TGDIplus GDIplus;
 try
 {
  Application->Initialize();
  Application->CreateForm(__classid(TMainWindow), &MainWindow);
  Application->CreateForm(__classid(TOptionsDialog), &OptionsDialog);
  Application->CreateForm(__classid(TCompareDialog2), &CompareDialog2);
  Application->CreateForm(__classid(TDeleteDialog2), &DeleteDialog2);
  Application->CreateForm(__classid(TAboutDialog), &AboutDialog);
  Application->Run();
 }
 catch(Exception &exception)
 {
  Application->ShowException(&exception);
 }
 catch (...)
 {
  try
  {
   throw Exception("Unknown exception.");
  }
  catch (Exception &exception)
  {
   Application->ShowException(&exception);
  }
 }
 return 0;
}
//---------------------------------------------------------------------------
