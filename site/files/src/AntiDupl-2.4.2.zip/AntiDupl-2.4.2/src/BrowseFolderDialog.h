/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
#ifndef __BrowseFolderDialog_h__
#define __BrowseFolderDialog_h__

#include <SysUtils.hpp>
//------------------------------------------------------------------------------
bool SelectFolder(const AnsiString &sCaption, AnsiString& Path, HWND hWndOwner);
//------------------------------------------------------------------------------
#endif //__BrowseFolderDialog_h__
