/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
#ifndef __Utils_h__
#define __Utils_h__

#include <vcl.h>
//--------Function:----------------------------------------------------------
//Graphic:
void StretchBitmapToImage(TImage *pImage, Graphics::TBitmap *pBitmap);
//String:
AnsiString IntToGroupedString(int nInteger);// Convert, for exanple, 2345678 to "2 345 678";
//File:
int FileDelete(AnsiString FileName, bool bRecycle);
bool DirExists(AnsiString DirName);
AnsiString GetWinDir(void);
AnsiString GetAppDir(void);
AnsiString GetUniqueFileName(const AnsiString& oldPath, const AnsiString& newExtension);
//Time:
AnsiString GetDataAndTime(void);
//--------Classes:-----------------------------------------------------------
class TSimpleTimer
{
private:
  __int64 m_nStart;
  __int64 m_nEnd;
  
public:
 TSimpleTimer(void):m_nStart(0), m_nEnd(0){};
 ~TSimpleTimer(void){};

 void Start(void);
 void End(void);
 double Time(void);
};
//---------------------------------------------------------------------------
class TSlotTimer
{
private:
 __int64 m_nLastTime;
 int m_nSlot;

public:
 TSlotTimer(int nSlot = 10); //in millisecond;
 ~TSlotTimer(void) {};

 void SetSlot(int nSlot);
 int Slot(void) const;
 bool TimeChanged(void);
};
//---------------------------------------------------------------------------
#endif //__Utils_h__
