/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
#include "SearchImage.h"
#include "Utils.h"
#include "DeleteDialogUnit2.h"
#include "CompareDialogUnit2.h"
#include "MainWindowUnit.h"
#include "MistakeDataBase.h"
//---------------class TSearch:----------------------------------------------
TSearch::TSearch(TShowProgress *pShowProgress)
 :m_pOptions(0)
{
 m_pShowProgress = pShowProgress;
 m_nCurrent = -1;
 m_eState = WAIT;
}
//---------------------------------------------------------------------------
TSearch::~TSearch(void)
{
}
//---------------------------------------------------------------------------
AnsiString TSearch::CurentFileName(void) const
{
 if(Current() > 0)
 {
  AnsiString Temp = m_Data[m_nCurrent].m_sFileName;
  Temp.Delete(1, m_pOptions->m_sDirectoryName.Length());
  return "..." + Temp;
 }
 else
  return AnsiString("");
};
//---------------------------------------------------------------------------
void TSearch::Execute(TOptions *pOptions)
{
 m_pShowProgress->ShowProgress(E_BeginSearch);
 m_pOptions = pOptions;
 if(!DirExists(m_pOptions->m_sDirectoryName))
 {
  m_pOptions->m_sDirectoryName = GetCurrentDir();
  return;
 }
 if(!(m_pOptions->m_bCheckOnDefect || m_pOptions->m_bCheckOnEquality))
  return;
 int nCompOrder = m_pOptions->m_nCompareOder*COMPARE_ORDER_VALUE;
 m_nMaxFastSum = PIXELS_SIZE*nCompOrder*nCompOrder;
 m_nMaxSlowSum = PIXELS_SIZE*PIXELS_SIZE*nCompOrder*nCompOrder;
 m_Data.clear();
 m_Result.clear();
 m_CurrentSearchStatistic.Clear();
 m_nCurrent = -1;
 m_eState = SEARCH;
 SearchImages(m_pOptions->m_sDirectoryName);
 if(m_eState)
 {
  m_eState = SCAN;
  m_pShowProgress->ShowProgress(E_BeginScan);
  ScanImages();
  m_pShowProgress->ShowProgress(E_EndScan);
 }
 m_eState = RESULT;
 m_pShowProgress->ShowProgress(E_ShowResults);
 ShowResult();
 m_pShowProgress->ShowProgress(E_ShowStatistic);
 m_eState = WAIT;
 m_nCurrent = -1;
 m_Data.clear();
 m_Result.clear();
};
//---------------------------------------------------------------------------
void TSearch::SearchImages(AnsiString sDirectory)
{
 m_CurrentSearchStatistic.m_nScanedFoldersNumber++;
 TSearchRec SearchRec;
 SetCurrentDir(sDirectory);
 AnsiString Temp;
 if(FindFirst("*", faAnyFile, SearchRec) == 0 && m_eState)
 {
  if(sDirectory.Length() == 3)
   Temp = sDirectory + SearchRec.Name;
  else
   Temp = sDirectory + "\\" + SearchRec.Name;
  if(SupportedFormat(Temp))
  {
   m_Data.push_back(TCollectedData(GetKeySize()));
   m_Data.back().m_sFileName = Temp;
   m_Data.back().m_nFileSize = SearchRec.Size;
   m_Data.back().m_nFileTime = SearchRec.Time;
   m_CurrentSearchStatistic.m_nSearchedImagesNumber++;
   m_pShowProgress->ShowProgress();
  }
  else
   if(((SearchRec.Attr & faDirectory) > 0) && (SearchRec.Name != ".") &&
      (SearchRec.Name != "..") && m_pOptions->m_bSubDirectories)
    SearchImages(Temp);
  while((FindNext(SearchRec) == 0) && m_eState)
  {
   if(sDirectory.Length() == 3)
    Temp = sDirectory + SearchRec.Name;
   else
    Temp = sDirectory + "\\" + SearchRec.Name;
   if(SupportedFormat(Temp))
   {
    m_Data.push_back(TCollectedData(GetKeySize()));
    m_Data.back().m_sFileName = Temp;
    m_Data.back().m_nFileSize = SearchRec.Size;
    m_Data.back().m_nFileTime = SearchRec.Time;
    m_CurrentSearchStatistic.m_nSearchedImagesNumber++;
    m_pShowProgress->ShowProgress();
   }
   else
    if(((SearchRec.Attr & faDirectory) > 0) && (SearchRec.Name != ".") &&
       (SearchRec.Name != "..") && m_pOptions->m_bSubDirectories)
     SearchImages(Temp);
  };
 };
 FindClose(SearchRec);
};
//---------------------------------------------------------------------------
bool TSearch::SupportedFormat(AnsiString sFileName)
{
 AnsiString sExt = ExtractFileExt(sFileName);
 if(m_pOptions->m_bSearchJPG && (CompareText(sExt,".JPG") == 0 || CompareText(sExt,".JPEG") == 0))
  return true;
 else if(m_pOptions->m_bSearchTIF && (CompareText(sExt,".TIF") == 0 || CompareText(sExt,".TIFF") == 0))
  return true;
 else if(m_pOptions->m_bSearchBMP && CompareText(sExt,".BMP") == 0)
  return true;
 else if(m_pOptions->m_bSearchGIF && CompareText(sExt,".GIF") == 0)
  return true;
 else if(m_pOptions->m_bSearchPNG && CompareText(sExt,".PNG") == 0)
  return true;
 else
  return false;
};
//---------------------------------------------------------------------------
int TSearch::GetKeySize(void)
{
 return PIXELS_SIZE*PIXELS_SIZE*sizeof(unsigned char);
};
//---------------------------------------------------------------------------
unsigned char TSearch::GetGray(TColor Color)
{
 float fGray;
 fGray = (Color&0x00ff0000)/0x00010000;
 fGray += (Color&0x0000ff00)/0x00000100;
 fGray += (Color&0x000000ff);
 fGray /= 3;
 return (unsigned char)(fGray + 0.5);
};
//---------------------------------------------------------------------------
bool TSearch::SetImageData(TCollectedData *pData)
{
 TGDIplusImage *pImage = new TGDIplusImage();
 bool bValidImage = true;
 if(pImage->Load(pData->m_sFileName))
 {
  if(pImage->Height() <= 0 || pImage->Width() <= 0)
  {
   SetDefectCase(pData);
   delete pImage;
   return (bool)pData->m_eImageFormat;
  }
  Graphics::TBitmap *pBitmap = new Graphics::TBitmap();
  pData->m_nImageHeight = pImage->Height();
  pData->m_nImageWidth = pImage->Width();
  if(pData->m_nImageWidth > pData->m_nImageHeight)
   pData->m_nRatio = pData->m_nImageHeight*RATIO_RESOLUTION/pData->m_nImageWidth - RATIO_RESOLUTION;
  else
   pData->m_nRatio = -(pData->m_nImageWidth*RATIO_RESOLUTION/pData->m_nImageHeight - RATIO_RESOLUTION);
  unsigned char *pKeyPixels = (unsigned char*)pData->m_pKey;
  if(m_pOptions->m_bFullPicture)
  {
   bValidImage = pImage->GetBitmap(pBitmap);
   for(int i_x = 0; i_x < PIXELS_SIZE; i_x++)
   {
    int b_x = i_x*pBitmap->Width/PIXELS_SIZE;
    for(int i_y = 0; i_y < PIXELS_SIZE; i_y++)
    {
     int b_y = i_y*pBitmap->Height/PIXELS_SIZE;
     pKeyPixels[i_x*PIXELS_SIZE + i_y] = GetGray(pBitmap->Canvas->Pixels[b_x][b_y]);
    };
   };
  }
  else
  {
   bValidImage = pImage->GetThumbnail(PIXELS_SIZE, PIXELS_SIZE, pBitmap);
   for(int i_x = 0; i_x < PIXELS_SIZE; i_x++)
    for(int i_y = 0; i_y < PIXELS_SIZE; i_y++)
     pKeyPixels[i_x*PIXELS_SIZE + i_y] = GetGray(pBitmap->Canvas->Pixels[i_x][i_y]);
  };
  delete pBitmap; 
 };  
 pData->m_eImageFormat = pImage->GetFormat();
 if(!bValidImage)
  SetDefectCase(pData);
 delete pImage;
 return (bool)pData->m_eImageFormat;
};
//---------------------------------------------------------------------------
void TSearch::ScanImages(void)
{
 m_nCurrent = 0;
 while(m_nCurrent < Total() && m_eState)
 {
  if(SetImageData(&(m_Data[m_nCurrent])))
  {
   if(m_pOptions->m_bCheckOnDefect)
    CheckOnDefect(&(m_Data[m_nCurrent]));
   if(m_pOptions->m_bCheckOnEquality)
    CheckOnEquality();
  };
  m_CurrentSearchStatistic.m_nScanedImagesNumber++;
  m_pShowProgress->ShowProgress();
  m_nCurrent++;
 };
 m_nCurrent--; 
};
//---------------------------------------------------------------------------
void TSearch::CheckOnDefect(TCollectedData *pData)
{
 bool defect = false;
 if(pData->m_eImageFormat == TGDIplusImage::JPG)
 {
  int nFileHandle;
  unsigned char EndMarker[2] = " ";
  nFileHandle = FileOpen(pData->m_sFileName, fmOpenRead);
  if(nFileHandle >= 0)
  {
   FileSeek(nFileHandle, -2, 2);
   FileRead(nFileHandle, &EndMarker, 2);
  }
  FileClose(nFileHandle);
  if((EndMarker[0] != 0xff) || (EndMarker[1] != 0xd9))
   defect = true;
 }
 if(defect &&
    m_pOptions->m_bMistakeDataBaseEnabled &&
    g_pMistakeDataBase &&
    g_pMistakeDataBase->IsHas(*pData))
  defect = false;
 if(defect)
  SetDefectCase(pData);
}
//---------------------------------------------------------------------------
void TSearch::CheckOnEquality(void)
{
 TCollectedData *pCurrent = &(m_Data[m_nCurrent]);
 int nDifference;
 for(int i_d = 0; i_d < m_nCurrent && pCurrent->m_eImageFormat; i_d++)
 {
  if(!m_Data[i_d].m_eImageFormat)
   continue;
  if(EqualImages(pCurrent, &(m_Data[i_d]), &nDifference))
  {
   m_CurrentSearchStatistic.m_nResultsNumber++;
   if(m_pOptions->m_bAutoDeleteEqual && AutoDeleteEqual(pCurrent, &(m_Data[i_d]), nDifference))
    continue;
   if(m_pOptions->m_bQueryDuringSearch)
   {
    switch(CompareDialog2->Show(m_pOptions, pCurrent, &(m_Data[i_d])))
    {
     case TCompareDialog2::NEXT:
      break;
     case TCompareDialog2::STOP:
      Stop();
      return;
     case TCompareDialog2::LEFTDEL:
      DeleteImage(pCurrent);
      break;
     case TCompareDialog2::RIGHTDEL:
      DeleteImage(&(m_Data[i_d]));
      break;
     case TCompareDialog2::LEFTMOVE:
      ReplaceImage(pCurrent, &(m_Data[i_d]));
      break;
     case TCompareDialog2::RIGHTMOVE:
      ReplaceImage(&(m_Data[i_d]), pCurrent);
      break;
     case TCompareDialog2::DELETEBOTH:
      DeleteImage(pCurrent);
      DeleteImage(&(m_Data[i_d]));
      break;
     case TCompareDialog2::MISTAKE:
      if(g_pMistakeDataBase && m_pOptions->m_bMistakeDataBaseEnabled)
      {
       TMistakePair pair(*pCurrent, m_Data[i_d]);
       g_pMistakeDataBase->Add(pair);
      }
      break;
    }
   }
   else
   {
    TSearchResult Result;
    Result.m_eType = TSearchResult::EQUAL;
    Result.m_Left = *pCurrent;
    Result.m_Right = m_Data[i_d];
    m_Result.push_back(Result);
   }
  }
 }
}
//---------------------------------------------------------------------------
bool TSearch::EqualImages(TCollectedData *pCurrent, TCollectedData *pData, int *pDifference)
{
 if(m_pOptions->m_bFormatControl && pCurrent->m_eImageFormat != pData->m_eImageFormat)
  return false;
 if(m_pOptions->m_bSizeControl &&
    (pCurrent->m_nImageHeight != pData->m_nImageHeight || 
     pCurrent->m_nImageWidth != pData->m_nImageWidth))
  return false;
 int nRatioDiff = pCurrent->m_nRatio - pData->m_nRatio,
     nMaxRatDiff = RATIO_DIFFERENCE*m_pOptions->m_nCompareOder;
 if(nRatioDiff > nMaxRatDiff || nRatioDiff < -nMaxRatDiff)
  return false;
 int nDiff, nPix, nSum = 0;
 unsigned char *pCPix = (unsigned char*)pCurrent->m_pKey,
               *pDPix = (unsigned char*)pData->m_pKey;
 for(int i_f = 0; i_f < PIXELS_SIZE; i_f += 4)
 {
  nPix = i_f*PIXELS_SIZE + i_f;
  nDiff = pCPix[nPix] - pDPix[nPix];
  nSum += nDiff*nDiff;
  nPix = i_f*PIXELS_SIZE + PIXELS_SIZE - i_f;
  nDiff = pCPix[nPix] - pDPix[nPix];
  nSum += nDiff*nDiff;
 }
 if(nSum > m_nMaxFastSum)
  return false;
 for(int i_f = PIXELS_SIZE*PIXELS_SIZE - 1; i_f >= 0; i_f--)
 {
  nDiff = pCPix[i_f] - pDPix[i_f];
  nSum += nDiff*nDiff;
 }
 if(nSum > m_nMaxSlowSum)
  return false;
 if(g_pMistakeDataBase && m_pOptions->m_bMistakeDataBaseEnabled)
 {
  TMistakePair pair(*pCurrent, *pData);
  if(g_pMistakeDataBase->IsHas(pair))
   return false;
 }
 *pDifference = nSum;
 return true;
}
//---------------------------------------------------------------------------
void TSearch::ShowResult(void)
{
 TImageInf *pLeft, *pRight;
 for(m_nCurrent = 0; m_nCurrent < (int)m_Result.size() && m_eState; m_nCurrent++)
 {
  pLeft = &(m_Result[m_nCurrent].m_Left);
  pRight = &(m_Result[m_nCurrent].m_Right);
  if(m_Result[m_nCurrent].m_eType == TSearchResult::DEFECT &&
     pLeft->m_eImageFormat && FileExists(pLeft->m_sFileName))
  {
   switch(DeleteDialog2->Show(m_pOptions, pLeft))
   {
    case TDeleteDialog2::NEXT:
     break;
    case TDeleteDialog2::STOP:
     Stop();
     return;
    case TDeleteDialog2::DEL:
     DeleteImage(pLeft);
     break;
    case TDeleteDialog2::MISTAKE:
     if(g_pMistakeDataBase && m_pOptions->m_bMistakeDataBaseEnabled)
      g_pMistakeDataBase->Add(*pLeft);
     break;
   }
  }
  if(m_Result[m_nCurrent].m_eType == TSearchResult::EQUAL &&
     pLeft->m_eImageFormat && pRight->m_eImageFormat &&
     FileExists(pLeft->m_sFileName) && FileExists(pRight->m_sFileName))
  {
   switch(CompareDialog2->Show(m_pOptions, pLeft, pRight))
   {
    case TCompareDialog2::NEXT:
     break;
    case TCompareDialog2::STOP:
     Stop();
     return;
    case TCompareDialog2::LEFTDEL:
     DeleteImage(pLeft);
     break;
    case TCompareDialog2::RIGHTDEL:
     DeleteImage(pRight);
     break;
    case TCompareDialog2::LEFTMOVE:
     ReplaceImage(pLeft, pRight);
     break;
    case TCompareDialog2::RIGHTMOVE:
     ReplaceImage(pRight, pLeft);
     break;
    case TCompareDialog2::DELETEBOTH:
     DeleteImage(pLeft);
     DeleteImage(pRight);
     break;
    case TCompareDialog2::MISTAKE:
     if(g_pMistakeDataBase && m_pOptions->m_bMistakeDataBaseEnabled)
     {
      TMistakePair pair(*pLeft, *pRight);
      g_pMistakeDataBase->Add(pair);
     }
     break;
   }
  }
  m_pShowProgress->ShowProgress();
 }
}

void TSearch::DeleteImage(TImageInf *pImageInf)
{
 m_CurrentSearchStatistic.m_nDeletedImagesNumber++;
 m_CurrentSearchStatistic.m_nDeletedImagesSize += pImageInf->m_nFileSize;
 FileDelete(pImageInf->m_sFileName, m_pOptions->m_bDeleteToRecycleBin);
 pImageInf->m_eImageFormat = TGDIplusImage::NON;
}

void TSearch::ReplaceImage(TImageInf *pFromImageInf, TImageInf *pToImageInf)
{
 m_CurrentSearchStatistic.m_nDeletedImagesNumber++;
 m_CurrentSearchStatistic.m_nDeletedImagesSize += pToImageInf->m_nFileSize;
 FileDelete(pToImageInf->m_sFileName, false);
 if(pToImageInf->m_eImageFormat == pFromImageInf->m_eImageFormat)
 {
  RenameFile(pFromImageInf->m_sFileName, pToImageInf->m_sFileName);
  pFromImageInf->m_sFileName = pToImageInf->m_sFileName;
 }
 else
 {
  AnsiString newName = GetUniqueFileName(pToImageInf->m_sFileName,
   ExtractFileExt(pFromImageInf->m_sFileName));
  RenameFile(pFromImageInf->m_sFileName, newName);
  pFromImageInf->m_sFileName = newName;
 }
 pToImageInf->m_eImageFormat = TGDIplusImage::NON;
}

int TSearch::Total(void) const
{
 switch(m_eState)
 {
  case SCAN:
   return (int)m_Data.size();
  case SEARCH:
   return (int)m_Data.size();
  case RESULT:
   return (int)m_Result.size();
  default:
   return 0;
 }
}

void TSearch::Stop(void)
{
 if (m_eState != WAIT)
 {
  m_pShowProgress->ShowProgress(E_Stopped);
  m_eState = WAIT;
 }
}

bool TSearch::AutoDeleteEqual(TCollectedData *pCurrent, TCollectedData *pData, int nDifference)
{
 if(nDifference == 0)
 {
  DeleteImage(pCurrent);
  return true;
 }
 return false;
}

void TSearch::SetDefectCase(TCollectedData *pData)
{
 m_CurrentSearchStatistic.m_nResultsNumber++;
 if(m_pOptions->m_bAutoDeleteDefect)
 {
  DeleteImage(pData);
 }
 else
 {
  if(m_pOptions->m_bQueryDuringSearch)
  {
   switch(DeleteDialog2->Show(m_pOptions, pData))
   {
    case TDeleteDialog2::NEXT:
     break;
    case TDeleteDialog2::STOP:
     Stop();
     return;
    case TDeleteDialog2::DEL:
     DeleteImage(pData);
     break;
    case TDeleteDialog2::MISTAKE:
     if(g_pMistakeDataBase && m_pOptions->m_bMistakeDataBaseEnabled)
      g_pMistakeDataBase->Add(*pData);
     break;
   }
  }
  else
  {
   TSearchResult Result;
   Result.m_eType = TSearchResult::DEFECT;
   Result.m_Left = *pData;
   m_Result.push_back(Result);
  }
 }
}
//---------------------------------------------------------------------------




