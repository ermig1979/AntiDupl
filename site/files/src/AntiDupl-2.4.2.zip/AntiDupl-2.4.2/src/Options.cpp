/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
#include "Options.h"
#include "Utils.h"

#include <inifiles.hpp>
#include <dir.h>

//---------------------------------------------------------------------------
TOptions::TOptions(void)
{
  Default();
};
//---------------------------------------------------------------------------
TOptions::TOptions(AnsiString FileName)
{
  if(!Load(FileName))
    Default();
};
//---------------------------------------------------------------------------
TOptions::TOptions(const TOptions &Options)
{
  *this = Options;
};
//---------------------------------------------------------------------------
TOptions::~TOptions(void)
{
};  
//---------------------------------------------------------------------------
void TOptions::Default(void)
{
  m_bAutoDeleteDefect = Default_AutoDeleteDefect;
  m_bAutoDeleteEqual = Default_AutoDeleteEqual;
  m_bCheckOnDefect = Default_CheckOnDefect;
  m_bCheckOnEquality = Default_CheckOnEquality;
  m_nCompareOder = Default_CompareOder;
  m_bDeleteToRecycleBin = Default_DeleteToRecycleBin;
  m_bSizeControl = Default_SizeControl;
  m_bFullPicture = Default_FullPicture;
  m_bSubDirectories = Default_SubDirectories;
  m_bQueryDuringSearch = Default_QueryDuringSearch;
  m_sDirectoryName = GetCurrentDir();
  m_sLanguage = Default_Language;
  m_nDeleteDialogHeight = Default_DeleteDialogHeight;
  m_nDeleteDialogWidth = Default_DeleteDialogWidth;
  m_nCompareDialogHeight = Default_CompareDialogHeight;
  m_nCompareDialogWidth = Default_CompareDialogWidth;
  m_bShowSpeedButtons = Default_ShowSpeedButtons;
  m_bShowStatusBar = Default_ShowStatusBar;
  m_bFormatControl = Default_FormatControl;
  m_bSearchJPG = Default_SearchJPG;
  m_bSearchBMP = Default_SearchBMP;
  m_bSearchGIF = Default_SearchGIF;
  m_bSearchPNG = Default_SearchPNG;
  m_bSearchTIF = Default_SearchTIF;
  m_bMistakeDataBaseEnabled = Default_MistakeDataBaseEnabled;
};
//---------------------------------------------------------------------------
TOptions& TOptions::operator=(const TOptions &Options)
{
  m_bAutoDeleteDefect = Options.m_bAutoDeleteDefect;
  m_bAutoDeleteEqual = Options.m_bAutoDeleteEqual;
  m_bCheckOnDefect = Options.m_bCheckOnDefect;
  m_bCheckOnEquality = Options.m_bCheckOnEquality;
  m_nCompareOder = Options.m_nCompareOder;
  m_bDeleteToRecycleBin = Options.m_bDeleteToRecycleBin;
  m_bSizeControl = Options.m_bSizeControl;
  m_bFullPicture = Options.m_bFullPicture;
  m_bQueryDuringSearch = Options.m_bQueryDuringSearch;
  m_bSubDirectories = Options.m_bSubDirectories;
  m_sDirectoryName = Options.m_sDirectoryName;
  m_sLanguage = Options.m_sLanguage;
  m_nDeleteDialogHeight = Options.m_nDeleteDialogHeight;
  m_nDeleteDialogWidth = Options.m_nDeleteDialogWidth;
  m_nCompareDialogHeight = Options.m_nCompareDialogHeight;
  m_nCompareDialogWidth = Options.m_nCompareDialogWidth;
  m_bShowSpeedButtons = Options.m_bShowSpeedButtons;
  m_bShowStatusBar = Options.m_bShowStatusBar;
  m_bFormatControl = Options.m_bFormatControl;
  m_bSearchJPG = Options.m_bSearchJPG;
  m_bSearchBMP = Options.m_bSearchBMP;
  m_bSearchGIF = Options.m_bSearchGIF;
  m_bSearchPNG = Options.m_bSearchPNG;
  m_bSearchTIF = Options.m_bSearchTIF;
  m_bMistakeDataBaseEnabled = Options.m_bMistakeDataBaseEnabled;
  return *this;
};
//---------------------------------------------------------------------------
bool TOptions::Load(AnsiString FileName)
{
  if(FileExists(FileName))
  {
    TIniFile *pIni = new TIniFile(FileName);
    m_bAutoDeleteDefect = pIni->ReadBool("Options", "AutoDeleteDefect", Default_AutoDeleteDefect);
    m_bAutoDeleteEqual = pIni->ReadBool("Options", "AutoDeleteEqual", Default_AutoDeleteEqual);
    m_bDeleteToRecycleBin = pIni->ReadBool("Options", "DeleteToRecycleBin", Default_DeleteToRecycleBin);
    m_bCheckOnDefect = pIni->ReadBool("Options", "CheckOnDefect", Default_CheckOnDefect);
    m_bCheckOnEquality = pIni->ReadBool("Options", "CheckOnEquality", Default_CheckOnEquality);
    m_bFullPicture = pIni->ReadBool("Options", "FullPicture", Default_FullPicture);
    m_bSizeControl = pIni->ReadBool("Options", "SizeControl", Default_SizeControl);
    m_bQueryDuringSearch = pIni->ReadBool("Options", "QueryDuringSearch", Default_QueryDuringSearch);
    m_nCompareOder = pIni->ReadInteger("Options", "CompareOder", Default_CompareOder);
    if(m_nCompareOder < 0 || m_nCompareOder > Maximal_CompareOder)
      m_nCompareOder = Default_CompareOder;
    m_sDirectoryName = pIni->ReadString("Options", "DirectoryName", GetCurrentDir());
    if(!DirExists(m_sDirectoryName))
      m_sDirectoryName = GetCurrentDir();
    m_bSubDirectories = pIni->ReadBool("Options", "SubDirectories", Default_SubDirectories);
    m_sLanguage = pIni->ReadString("Options", "Language", Default_Language);
    m_nDeleteDialogHeight = pIni->ReadInteger("Size", "DeleteDialogHeight", Default_DeleteDialogHeight);
    if(m_nDeleteDialogHeight < Default_DeleteDialogHeight)
      m_nDeleteDialogHeight = Default_DeleteDialogHeight;
    m_nDeleteDialogWidth = pIni->ReadInteger("Size", "DeleteDialogWidth", Default_DeleteDialogWidth);
    if(m_nDeleteDialogWidth < Default_DeleteDialogWidth)
      m_nDeleteDialogWidth = Default_DeleteDialogWidth;
    m_nCompareDialogHeight = pIni->ReadInteger("Size", "CompareDialogHeight", Default_CompareDialogHeight);
    if(m_nCompareDialogHeight < Default_CompareDialogHeight)
      m_nCompareDialogHeight = Default_CompareDialogHeight;
    m_nCompareDialogWidth = pIni->ReadInteger("Size", "CompareDialogWidth", Default_CompareDialogWidth);
    if(m_nCompareDialogWidth < Default_CompareDialogWidth)
      m_nCompareDialogWidth = Default_CompareDialogWidth;
    m_bShowSpeedButtons = pIni->ReadBool("View", "ShowSpeedButtons", Default_ShowSpeedButtons);
    m_bShowStatusBar = pIni->ReadBool("View", "ShowStatusBar", Default_ShowStatusBar);
    m_bFormatControl = pIni->ReadBool("Options", "FormatControl", Default_FormatControl);
    m_bSearchJPG = pIni->ReadBool("Options", "SearchJPG", Default_SearchJPG);
    m_bSearchBMP = pIni->ReadBool("Options", "SearchBMP", Default_SearchBMP);
    m_bSearchGIF = pIni->ReadBool("Options", "SearchGIF", Default_SearchGIF);
    m_bSearchPNG = pIni->ReadBool("Options", "SearchPNG", Default_SearchPNG);
    m_bSearchTIF = pIni->ReadBool("Options", "SearchTIF", Default_SearchTIF);
    m_bMistakeDataBaseEnabled = pIni->ReadBool("Options", "MistakeDataBaseEnabled", Default_MistakeDataBaseEnabled);
    delete pIni;
    return true;
  }
  else
    return false;
};  
//---------------------------------------------------------------------------
bool TOptions::Save(AnsiString FileName)
{
  if(!FileExists(FileName)) FileClose(FileCreate(FileName));
  TIniFile *pIni = new TIniFile(FileName);
  pIni->WriteBool("Options", "AutoDeleteDefect", m_bAutoDeleteDefect);
  pIni->WriteBool("Options", "AutoDeleteEqual", m_bAutoDeleteEqual);
  pIni->WriteBool("Options", "DeleteToRecycleBin", m_bDeleteToRecycleBin);
  pIni->WriteBool("Options", "CheckOnDefect", m_bCheckOnDefect);
  pIni->WriteBool("Options", "CheckOnEquality", m_bCheckOnEquality);
  pIni->WriteBool("Options", "FullPicture", m_bFullPicture);
  pIni->WriteBool("Options", "SizeControl", m_bSizeControl);
  pIni->WriteBool("Options", "QueryDuringSearch", m_bQueryDuringSearch);
  pIni->WriteInteger("Options", "CompareOder", m_nCompareOder);
  pIni->WriteString("Options", "DirectoryName", m_sDirectoryName);
  pIni->WriteBool("Options", "SubDirectories", m_bSubDirectories);
  pIni->WriteString("Options", "Language", m_sLanguage);
  pIni->WriteInteger("Size", "DeleteDialogHeight", m_nDeleteDialogHeight);
  pIni->WriteInteger("Size", "DeleteDialogWidth", m_nDeleteDialogWidth);
  pIni->WriteInteger("Size", "CompareDialogHeight", m_nCompareDialogHeight);
  pIni->WriteInteger("Size", "CompareDialogWidth", m_nCompareDialogWidth);
  pIni->WriteBool("View", "ShowSpeedButtons", m_bShowSpeedButtons);
  pIni->WriteBool("View", "ShowStatusBar", m_bShowStatusBar);
  pIni->WriteBool("Options", "FormatControl", m_bFormatControl);
  pIni->WriteBool("Options", "SearchJPG", m_bSearchJPG);
  pIni->WriteBool("Options", "SearchBMP", m_bSearchBMP);
  pIni->WriteBool("Options", "SearchGIF", m_bSearchGIF);
  pIni->WriteBool("Options", "SearchPNG", m_bSearchPNG);
  pIni->WriteBool("Options", "SearchTIF", m_bSearchTIF);
  pIni->WriteBool("Options", "MistakeDataBaseEnabled", m_bMistakeDataBaseEnabled);
  pIni->UpdateFile();
  delete pIni;
  return true;
};
//--------------TCaption:-------------------------------------------------------
const AnsiString c_sZeroString = "";

TStringStorage::TStringStorage(const AnsiString &sFileName)
 :m_sFileName(sFileName)
{
}

bool TStringStorage::Load(const AnsiString &sLanguage)
{
 if(FileExists(m_sFileName))
 {
  TIniFile *pIni = new TIniFile(m_sFileName);
  int n_s = pIni->ReadInteger("Common", "Number", 0);
  m_sStrings.resize(n_s);
  for(int i_s = 0; i_s < n_s; i_s++)
   m_sStrings[i_s] = pIni->ReadString(sLanguage, "Str[" + IntToStr(i_s) + "]", c_sZeroString);
  delete pIni;
  return true;
 }
 else
  return false;
}

const AnsiString& TStringStorage::Get(int N) const
{
 if(N >= 0 && N < (int)m_sStrings.size())
  return m_sStrings[N];
 else
  return c_sZeroString;
}
//---------------------------------------------------------------------------
TStringStorage *g_pStr;
//---------------------------------------------------------------------------


















