/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
#include <vcl.h>
#include <vcl\Clipbrd.hpp>
#pragma hdrstop

#include "DeleteDialogUnit2.h"
#include "Utils.h"
#include "SearchImage.h"
#include "Options.h"
#include "GDIplusWrapper.h"
#include "MainWindowUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TDeleteDialog2 *DeleteDialog2;
//---------------------------------------------------------------------------
__fastcall TDeleteDialog2::TDeleteDialog2(TComponent* Owner)
  : TForm(Owner)
{
 m_eResult = STOP;
 DoubleBuffered = true;
}
//---------------------------------------------------------------------------
void __fastcall TDeleteDialog2::NextButtonClick(TObject *Sender)
{
 m_eResult = NEXT;
 Close();  
}
//---------------------------------------------------------------------------
void __fastcall TDeleteDialog2::DeleteButtonClick(TObject *Sender)
{
 m_eResult = DEL;
 Close();
}
//---------------------------------------------------------------------------
void __fastcall TDeleteDialog2::StopButtonClick(TObject *Sender)
{
 m_eResult = STOP;
 Close();
}
//---------------------------------------------------------------------------
TDeleteDialog2::EResult TDeleteDialog2::Show(TOptions *pOptions, TImageInf *pData)
{
 m_pOptions = pOptions;
 MainWindow->SetProgramState(PS_FOUND);
 QueryDuringSearch->Visible = pOptions->m_bQueryDuringSearch;
 QueryDuringSearch->Checked = pOptions->m_bQueryDuringSearch;
 MistakeButton->Visible = pOptions->m_bMistakeDataBaseEnabled;

 StopButton->Caption = g_pStr->Get(10);
 StopButton->Hint = g_pStr->Get(59);
 NextButton->Caption = g_pStr->Get(8);
 NextButton->Hint = g_pStr->Get(60);
 QueryDuringSearch->Caption = g_pStr->Get(31);
 Caption = g_pStr->Get(44);
 DeleteButton->Hint = g_pStr->Get(61);
 CopyPathPopupMenuItem->Caption = g_pStr->Get(74);
 OpenPicturePopupMenuItem->Caption = g_pStr->Get(75);
 MistakeButton->Caption = g_pStr->Get(76);
 MistakeButton->Hint = g_pStr->Get(77);

 m_eResult = STOP;
 TGDIplusImage *pImage = new TGDIplusImage();
 if(pImage->Load(pData->m_sFileName))
 {
  m_pBitmap = new Graphics::TBitmap();
  pImage->GetBitmap(m_pBitmap);
  FileSizeLabel->Caption = IntToGroupedString(pData->m_nFileSize) + " B";
  ImageSizeLabel->Caption = IntToStr(pData->m_nImageWidth) + "x" + IntToStr(pData->m_nImageHeight);
  AnsiString sTemp = pData->m_sFileName;
  sTemp.Delete(1, pOptions->m_sDirectoryName.Length());
  FileNameLabel->Caption = "..." + sTemp;
  FileNameLabel->Hint = pData->m_sFileName;
  Height = pOptions->m_nDeleteDialogHeight;
  Width = pOptions->m_nDeleteDialogWidth;
  StretchBitmapToImage(Image, m_pBitmap);
  ShowModal();
  pOptions->m_bQueryDuringSearch = QueryDuringSearch->Checked;
  pOptions->m_nDeleteDialogHeight = Height;
  pOptions->m_nDeleteDialogWidth = Width;
  delete m_pBitmap;
 };
 MainWindow->SetProgramState(PS_RUN);
 delete pImage;
 return m_eResult;
};
//---------------------------------------------------------------------------
void __fastcall TDeleteDialog2::FormResize(TObject *Sender)
{
 const int ImageBorder = 4;
 int nWidth = ClientWidth - 2*ImageBorder - 1;

 StopButton->Top = ClientHeight - ImageBorder - StopButton->Height;
 StopButton->Left = ClientWidth - ImageBorder - StopButton->Width;

 NextButton->Top = ClientHeight - ImageBorder - NextButton->Height;
 NextButton->Left = ClientWidth/2 - NextButton->Width/2;

 MistakeButton->Top = ClientHeight - ImageBorder - MistakeButton->Height;
 MistakeButton->Left = (NextButton->Left + NextButton->Width + StopButton->Left)/2 - MistakeButton->Width/2;

 QueryDuringSearch->Top = ClientHeight - ImageBorder - QueryDuringSearch->Height;
 QueryDuringSearch->Left = ImageBorder;
 QueryDuringSearch->Width = NextButton->Left - ImageBorder*2;

 Bevel->Top = 0;
 Bevel->Left = 0;
 Bevel->Height = StopButton->Top - ImageBorder;
 Bevel->Width = ClientWidth;

 DeleteButton->Left = ClientWidth/2 - DeleteButton->Width/2;
 DeleteButton->Top = Bevel->Height - ImageBorder - DeleteButton->Height;

 ImageSizeLabel->Left = ImageBorder;
 ImageSizeLabel->Width = nWidth;
 ImageSizeLabel->Top = DeleteButton->Top - ImageSizeLabel->Height - ImageBorder/2;

 FileSizeLabel->Left = ImageBorder;
 FileSizeLabel->Width = nWidth;
 FileSizeLabel->Top = ImageSizeLabel->Top - FileSizeLabel->Height - ImageBorder/2;

 FileNameLabel->Left = ImageBorder;
 FileNameLabel->Width = nWidth;
 FileNameLabel->Top = FileSizeLabel->Top - FileNameLabel->Height - ImageBorder/2;

 Image->Top = ImageBorder;
 Image->Left = ImageBorder;
 Image->Width = nWidth;
 Image->Picture->Bitmap->Width = nWidth;
 Image->Height = FileNameLabel->Top - 2*ImageBorder;
 Image->Picture->Bitmap->Height = FileNameLabel->Top - 2*ImageBorder;
 StretchBitmapToImage(Image, m_pBitmap);
}
//---------------------------------------------------------------------------
void __fastcall TDeleteDialog2::FormKeyUp(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
 switch(Key)
 {
  case VK_PAUSE:
   m_eResult = STOP;
   Close();
   break;
  case VK_SHIFT:
   m_eResult = NEXT;
   Close();
   break;
  case VK_DELETE:
   m_eResult = DEL;
   Close();
   break;
  case VK_PRIOR:
   if(m_pOptions->m_bMistakeDataBaseEnabled)
   {
    m_eResult = MISTAKE;
    Close();
   }
   break;
 }
}
//---------------------------------------------------------------------------
void __fastcall TDeleteDialog2::OpenPicturePopupMenuItemClick(
      TObject *Sender)
{
 ShellExecute(Handle, "open", FileNameLabel->Hint.c_str(), NULL, NULL, SW_SHOWNORMAL);
}
//---------------------------------------------------------------------------
void __fastcall TDeleteDialog2::CopyPathPopupMenuItemClick(
      TObject *Sender)
{
 Clipboard()->AsText = FileNameLabel->Hint.c_str();
}
//---------------------------------------------------------------------------
void __fastcall TDeleteDialog2::MistakeButtonClick(TObject *Sender)
{
 m_eResult = MISTAKE;
 Close();
}
//---------------------------------------------------------------------------
void __fastcall TDeleteDialog2::ImageDblClick(TObject *Sender)
{
 ShellExecute(Handle, "open", FileNameLabel->Hint.c_str(), NULL, NULL, SW_SHOWNORMAL);
}
//---------------------------------------------------------------------------

