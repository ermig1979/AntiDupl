/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
//---------------------------------------------------------------------------

#ifndef AboutDialogUnitH
#define AboutDialogUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include <jpeg.hpp>
//---------------------------------------------------------------------------
class TOptions;
//---------------------------------------------------------------------------
class TAboutDialog : public TForm
{
__published:	// IDE-managed Components
  TLabel *AntiDuplLabel;
  TButton *OkButton;
  TImage *AboutImage;
  TLabel *VersionLabel;
  TLabel *PlaceLabel;
  TLabel *AdressLabel;
  TLabel *DataLabel;
  TLabel *AthorLabel;
  TBevel *Bevel;
  void __fastcall OkButtonClick(TObject *Sender);
  void __fastcall AdressLabelClick(TObject *Sender);
  void __fastcall FormCreate(TObject *Sender);
private:	// User declarations
public:		// User declarations
  __fastcall TAboutDialog(TComponent* Owner);
  void Show(TOptions *pOptions);
};
//---------------------------------------------------------------------------
extern PACKAGE TAboutDialog *AboutDialog;
//---------------------------------------------------------------------------
#endif
