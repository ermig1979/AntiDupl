/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
#ifndef __MistakeDataBase_h__
#define __MistakeDataBase_h__

#include <vector.h>
#include "SearchImageStruct.h"
//------------------------------------------------------------------------------
typedef TFileInf TMistake;
//------------------------------------------------------------------------------
class TMistakePair
{
public:
 TMistakePair(void) {};
 TMistakePair(const TMistake& left, const TMistake& right);
 TMistakePair(const TMistakePair &a) {*this = a;};
 ~TMistakePair(void) {};

 TMistakePair& operator=(const TMistakePair &a);

 bool operator==(const TMistakePair &a) const;
 bool operator!=(const TMistakePair &a) const {return !(*this == a);};
 bool operator>(const TMistakePair &a) const;
 bool operator<(const TMistakePair &a) const;

 bool Load(FILE* in);
 bool Save(FILE* out) const;

 const TMistake& Left(void) const {return m_left;};
 const TMistake& Right(void) const {return m_right;};

private:
 void Sort(void);

 TMistake m_left;
 TMistake m_right;
};
//------------------------------------------------------------------------------
class TMistakeDataBase
{
public:
 TMistakeDataBase(void);
 ~TMistakeDataBase(void) {};

 bool Save(const AnsiString &fileName);
 bool Load(const AnsiString &fileName);

 bool Add(const TMistakePair& pair);
 bool Add(const TMistake& single);
 bool IsHas(const TMistakePair& pair) const;
 bool IsHas(const TMistake& single) const;

 void Clear(void);
 void Merge(void);

private:
 std::vector<TMistake> m_mainSingle;
 std::vector<TMistake> m_newSingle;
 std::vector<TMistakePair> m_mainPair;
 std::vector<TMistakePair> m_newPair;
};
//------------------------------------------------------------------------------
extern TMistakeDataBase *g_pMistakeDataBase;
//------------------------------------------------------------------------------
#endif //__MistakeDataBase_h__
 