/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
#include <algorithm>
#include "MistakeDataBase.h"
//------------------------------------------------------------------------------
TMistakePair::TMistakePair(const TMistake& left, const TMistake& right)
 :m_left(left),
 m_right(right)
{
 Sort();
}

TMistakePair& TMistakePair::operator=(const TMistakePair &a)
{
 m_left = a.m_left;
 m_right = a.m_right;
 return *this;
}

bool TMistakePair::operator==(const TMistakePair &a) const
{
 return
  (m_left == a.m_left &&
   m_right == a.m_right);
}

bool TMistakePair::operator>(const TMistakePair &a) const
{
 return
  (m_left.m_sFileName > a.m_left.m_sFileName ||
   (m_left.m_sFileName == a.m_left.m_sFileName &&
    m_right.m_sFileName > a.m_right.m_sFileName));
}

bool TMistakePair::operator<(const TMistakePair &a) const
{
 return
  (m_left.m_sFileName < a.m_left.m_sFileName ||
   (m_left.m_sFileName == a.m_left.m_sFileName &&
    m_right.m_sFileName < a.m_right.m_sFileName));
}

bool TMistakePair::Load(FILE* in)
{
 if (!m_left.Load(in))
  return false;
 return m_right.Load(in);
}

bool TMistakePair::Save(FILE* out) const
{
 if (!m_left.Save(out))
  return false;
 return m_right.Save(out);
}

void TMistakePair::Sort(void)
{
 if(m_left.m_sFileName > m_right.m_sFileName)
 {
  TMistake tmp = m_right;
  m_right = m_left;
  m_left = tmp;
 }
}
//------------------------------------------------------------------------------
TMistakeDataBase::TMistakeDataBase(void)
{
}

bool TMistakeDataBase::Save(const AnsiString &fileName)
{
 FILE* file;
 size_t size, was_write;

 Merge();
 
 file = fopen(fileName.c_str(), "w");
 if(file == NULL)
  return false;
  
 size = m_mainSingle.size();

 was_write = fwrite(&size, sizeof(size_t), 1, file);
 if(was_write < 1)
 {
  fclose(file);
  return false;
 }

 for(size_t i = 0; i < size; i++)
 {
  if(!m_mainSingle[i].Save(file))
  {
   fclose(file);
   return false;
  }
 }

 size = m_mainPair.size();

 was_write = fwrite(&size, sizeof(size_t), 1, file);
 if(was_write < 1)
 {
  fclose(file);
  return false;
 }

 for(size_t i = 0; i < size; i++)
 {
  if(!m_mainPair[i].Save(file))
  {
   fclose(file);
   return false;
  }
 }

 fclose(file);
 return true;
}

bool TMistakeDataBase::Load(const AnsiString &fileName)
{
 FILE* file;
 size_t size, was_read;

 Clear();

 file = fopen(fileName.c_str(), "r");
 if(file == NULL)
  return false;

 was_read = fread(&size, sizeof(size_t), 1, file);
 if(was_read < 1 || size > 0xffffff)
 {
  fclose(file);
  return false;
 }

 m_mainSingle.resize(size);
 for(size_t i = 0; i < size; i++)
 {
  if(!m_mainSingle[i].Load(file))
  {
   fclose(file);
   Clear();
   return false;
  }
 }

 was_read = fread(&size, sizeof(size_t), 1, file);
 if(was_read < 1 || size > 0xffffff)
 {
  fclose(file);
  return false;
 }

 m_mainPair.resize(size);
 for(size_t i = 0; i < size; i++)
 {
  if(!m_mainPair[i].Load(file))
  {
   fclose(file);
   Clear();
   return false;
  }
 }

 fclose(file);
 return true;
}

void TMistakeDataBase::Clear(void)
{
 m_mainSingle.clear();
 m_newSingle.clear();
 m_mainPair.clear();
 m_newPair.clear();
}

void TMistakeDataBase::Merge(void)
{
 if(m_mainSingle.size() && m_newSingle.size())
 {
  std::vector<TMistake> tmp(m_mainSingle.size() + m_newSingle.size());
  std::merge(m_mainSingle.begin(), m_mainSingle.end(), m_newSingle.begin(),
   m_newSingle.end(), tmp.begin());
  m_mainSingle = tmp;
  m_newSingle.clear();
 }
 else
 {
  if(m_newSingle.size())
   m_mainSingle = m_newSingle;
  m_newSingle.clear();
 }
 
 if(m_mainPair.size() && m_newPair.size())
 {
  std::vector<TMistakePair> tmp(m_mainPair.size() + m_newPair.size());
  std::merge(m_mainPair.begin(), m_mainPair.end(), m_newPair.begin(),
   m_newPair.end(), tmp.begin());
  m_mainPair = tmp;
  m_newPair.clear();
 }
 else
 {
  if(m_newPair.size())
   m_mainPair = m_newPair;
  m_newPair.clear();
 }
}

bool TMistakeDataBase::Add(const TMistake& single)
{
 if(IsHas(single))
  return true;
 m_newSingle.insert(std::lower_bound(m_newSingle.begin(),
  m_newSingle.end(), single), single);
 if(m_newSingle.size() > DIFF_DB_MAX_NEW_SIZE)
  Merge();
 return true;
}

bool TMistakeDataBase::Add(const TMistakePair& pair)
{
 if(IsHas(pair))
  return true;
 m_newPair.insert(std::lower_bound(m_newPair.begin(), m_newPair.end(),
  pair), pair);
 if(m_newPair.size() > DIFF_DB_MAX_NEW_SIZE)
  Merge();
 return true;
}

bool TMistakeDataBase::IsHas(const TMistake& single) const
{
 const TMistake *pMain = std::lower_bound(m_mainSingle.begin(),
  m_mainSingle.end(), single);
 if(pMain && (pMain != m_mainSingle.end()) && (*pMain == single))
  return true;
 const TMistake *pNew = std::lower_bound(m_newSingle.begin(),
  m_newSingle.end(), single);
 if(pNew && (pNew != m_newSingle.end()) && (*pNew == single))
  return true;
 return false;
}

bool TMistakeDataBase::IsHas(const TMistakePair& pair) const
{
 const TMistakePair *pMain = std::lower_bound(m_mainPair.begin(),
  m_mainPair.end(), pair);
 if(pMain && (pMain != m_mainPair.end()) && (*pMain == pair))
  return true;
 const TMistakePair *pNew = std::lower_bound(m_newPair.begin(),
  m_newPair.end(), pair);
 if(pNew && (pNew != m_newPair.end()) && (*pNew == pair))
  return true;
 return false;
}
//------------------------------------------------------------------------------
TMistakeDataBase *g_pMistakeDataBase = NULL;
//------------------------------------------------------------------------------


 