/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
#pragma hdrstop

#include "Utils.h"
#include <sys/timeb.h>
#include <shellapi.h>
#include <windows.h>
#include <tchar.h>
#include <systdate.h>

#pragma package(smart_init)
//---------------------------------------------------------------------------
void StretchBitmapToImage(TImage *pImage, Graphics::TBitmap *pBitmap)
{
  TRect Rect;
  TColor TempBrushColor, TempPenColor, TempFontColor;
  TempBrushColor = pImage->Canvas->Brush->Color;
  TempPenColor = pImage->Canvas->Pen->Color;
  pImage->Canvas->Brush->Color = clDkGray;
  pImage->Canvas->Pen->Color = clDkGray;
  pImage->Canvas->Rectangle(0, 0, pImage->Width, pImage->Height);
  if(pBitmap->Width == 0 || pBitmap->Height == 0)
  {
   TempFontColor = pImage->Canvas->Font->Color;
   pImage->Canvas->Font->Color = clRed;
   AnsiString sErrorLabel = "Can't show picture!";
   pImage->Canvas->TextOutA(pImage->Width/2 - pImage->Canvas->TextWidth(sErrorLabel)/2,
    pImage->Height/2 - pImage->Canvas->TextHeight(sErrorLabel)/2, sErrorLabel);
   pImage->Canvas->Font->Color = TempFontColor;
   return;
  }
  pImage->Canvas->Brush->Color = TempBrushColor;
  pImage->Canvas->Pen->Color = TempPenColor;
  if(float(pBitmap->Width)/float(pBitmap->Height) >
     float(pImage->Width)/float(pImage->Height))
  {
   Rect.Left = 0;
   Rect.Right = pImage->Width;
   Rect.Top = (pImage->Height - (pImage->Width*pBitmap->Height)/pBitmap->Width)/2;
   Rect.Bottom = (pImage->Height + (pImage->Width*pBitmap->Height)/pBitmap->Width)/2;
  }
  else
  {
   Rect.Top = 0;
   Rect.Bottom = pImage->Height;
   Rect.Left = (pImage->Width - (pImage->Height*pBitmap->Width)/pBitmap->Height)/2;
   Rect.Right = (pImage->Width + (pImage->Height*pBitmap->Width)/pBitmap->Height)/2;
  };
  pImage->Canvas->StretchDraw(Rect, pBitmap);
};   
//---------------------------------------------------------------------------
AnsiString IntToGroupedString(int nInteger)
{
 AnsiString sResult = IntToStr(nInteger);
 int nSize; 
 if(nInteger >= 1000000000 || nInteger <= -1000000000)
 {
  sResult += "012";
  nSize = sResult.Length();
  sResult[nSize--] = sResult[nSize - 3];
  sResult[nSize--] = sResult[nSize - 3];
  sResult[nSize--] = sResult[nSize - 3];
  sResult[nSize--] = ' ';
  sResult[nSize--] = sResult[nSize - 2];
  sResult[nSize--] = sResult[nSize - 2];
  sResult[nSize--] = sResult[nSize - 2];
  sResult[nSize--] = ' ';
  sResult[nSize--] = sResult[nSize - 1];
  sResult[nSize--] = sResult[nSize - 1];
  sResult[nSize--] = sResult[nSize - 1];
  sResult[nSize--] = ' ';
 };
 if(nInteger >= 1000000 || nInteger <= -1000000)
 {
  sResult += "01";
  nSize = sResult.Length();
  sResult[nSize--] = sResult[nSize - 2];
  sResult[nSize--] = sResult[nSize - 2];
  sResult[nSize--] = sResult[nSize - 2];
  sResult[nSize--] = ' ';
  sResult[nSize--] = sResult[nSize - 1];
  sResult[nSize--] = sResult[nSize - 1];
  sResult[nSize--] = sResult[nSize - 1];
  sResult[nSize--] = ' ';
 };
 if(nInteger >= 1000 || nInteger <= -1000)
 {
  sResult += "0";
  nSize = sResult.Length();
  sResult[nSize--] = sResult[nSize - 1];
  sResult[nSize--] = sResult[nSize - 1];
  sResult[nSize--] = sResult[nSize - 1];
  sResult[nSize--] = ' ';
 };
 return sResult;
};
//------------------------------------------------------------------------------
int FileDelete(AnsiString FileName, bool bRecycle)
{
 TCHAR buf[_MAX_PATH + 1];
 _tcscpy(buf, FileName.c_str());
 buf[_tcslen(buf)+1] = 0;
 SHFILEOPSTRUCT del_var;
 ZeroMemory(&del_var, sizeof(del_var));
 del_var.wFunc = FO_DELETE;
 del_var.pTo = NULL;
 del_var.pFrom = buf;
 del_var.fFlags = FOF_SILENT | FOF_NOCONFIRMATION | FOF_NOERRORUI;
 if(bRecycle)
  del_var.fFlags |= FOF_ALLOWUNDO;
 else
  del_var.fFlags &= ~FOF_ALLOWUNDO;
 return SHFileOperation(&del_var);
};
//------------------------------------------------------------------------------
bool DirExists(AnsiString DirName)
{
 int Code;
 Code = GetFileAttributes(DirName.c_str());
 return ((Code != -1) && FILE_ATTRIBUTE_DIRECTORY && (Code != 0));
};
//------------------------------------------------------------------------------
AnsiString GetWinDir(void)
{
 char WinDir[MAX_PATH];
 GetWindowsDirectory(WinDir, MAX_PATH);
 return AnsiString(WinDir);
};
//---------------------------------------------------------------------------
AnsiString GetAppDir(void)
{
 return ExtractFilePath(Application->ExeName);
};
//---------------------------------------------------------------------------
AnsiString GetUniqueFileName(const AnsiString& oldPath, const AnsiString& newExtension)
{
 AnsiString uniqueName, newPath;
 newPath = oldPath.SubString(0, oldPath.Length() - ExtractFileExt(oldPath).Length());
 uniqueName = newPath + newExtension;
 for(unsigned int i = 0; FileExists(uniqueName) && i <= 0xffff; i++)
  uniqueName = newPath + "_" + IntToStr(i) + newExtension;
 return uniqueName;
}
//---------------------------------------------------------------------------
AnsiString GetDataAndTime(void)
{
 SYSTEMTIME sysTime;
 GetLocalTime(&sysTime);
 AnsiString sResult;
 if(sysTime.wDay < 10) sResult += "0";
 sResult += IntToStr(sysTime.wDay) + ".";
 if(sysTime.wMonth < 10) sResult += "0";
 sResult += IntToStr(sysTime.wMonth) + ".";
 sResult += IntToStr(sysTime.wYear) + " ";
 if(sysTime.wHour < 10) sResult += "0";
 sResult += IntToStr(sysTime.wHour) + ":";
 if(sysTime.wMinute < 10) sResult += "0";
 sResult += IntToStr(sysTime.wMinute) + ":";
 if(sysTime.wSecond < 10) sResult += "0";
 sResult += IntToStr(sysTime.wSecond);
 return  sResult;
}
//-------------TSimpleTimer:-------------------------------------------------
void TSimpleTimer::Start(void)
{
 timeb tbuf;
 ftime(&tbuf);
 m_nStart = tbuf.time*1000 + tbuf.millitm;
};
//---------------------------------------------------------------------------
void TSimpleTimer::End(void)
{
 timeb tbuf;
 ftime(&tbuf);
 m_nEnd = tbuf.time*1000 + tbuf.millitm;
};
//---------------------------------------------------------------------------
double TSimpleTimer::Time(void)
{
 return 0.001*(m_nEnd - m_nStart);
};
//-------------TSlotTimer:---------------------------------------------------
TSlotTimer::TSlotTimer(int nSlot)
 :m_nSlot(nSlot)
{
 timeb tbuf;
 ftime(&tbuf);
 m_nLastTime = tbuf.time*1000 + tbuf.millitm;
}

void TSlotTimer::SetSlot(int nSlot)
{
 m_nSlot = nSlot;
}

int TSlotTimer::Slot(void) const
{
 return m_nSlot;
}

bool TSlotTimer::TimeChanged(void)
{
 timeb tbuf;
 ftime(&tbuf);
 __int64 nCurrentTime = tbuf.time*1000 + tbuf.millitm;
 if(nCurrentTime - m_nLastTime > m_nSlot)
 {
  m_nLastTime = nCurrentTime;
  return true;
 }
 else
 {
  return false;
 }
}
//---------------------------------------------------------------------------

