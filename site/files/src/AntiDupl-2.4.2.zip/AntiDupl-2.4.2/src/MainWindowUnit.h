/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
//---------------------------------------------------------------------------

#ifndef MainWindowUnitH
#define MainWindowUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Menus.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <ToolWin.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
enum EProgramState
{
 PS_STOP = 0,
 PS_RUN = 1,
 PS_FOUND = 2
};
//---------------------------------------------------------------------------
class TOptions;
class TSearch;
class TSlotTimer;
//---------------------------------------------------------------------------
class TShowProgress
{
public:
 virtual void ShowProgress(int nEventType = 0, void *pEventData = 0) = 0;
};
//---------------------------------------------------------------------------
class TMainWindow : public TForm, public TShowProgress
{
__published:	// IDE-managed Components
  TMainMenu *MainMenu;
  TMenuItem *OptionsMenu;
  TMenuItem *HelpMenu;
  TMenuItem *AboutMenu;
  TMenuItem *StartMenu;
  TMenuItem *BrowseMenu;
  TStatusBar *StatusBar;
  TMenuItem *FileMenu;
  TMenuItem *N1;
  TMenuItem *ExitMenu;
  TMenuItem *ToolsMenu;
  TToolBar *ToolBar;
  TSpeedButton *StartSpeedButton;
  TSpeedButton *BrowseSpeedButton;
  TSpeedButton *OptionsSpeedButton;
  TSpeedButton *HelpSpeedButton;
  TMenuItem *StopMenu;
  TSpeedButton *StopSpeedButton;
  TMenuItem *ViewMenu;
  TMenuItem *ShowSpeedButtonsMenu;
  TMenuItem *ShowStatusBarMenu;
  TProgressBar *ProgressBar;
  TRichEdit *ProgressRichEdit;
  TMenuItem *HelpSubMenu;
  TMenuItem *ClearLogMenu;
  TPopupMenu *ProgressRichEditPopupMenu;
  TMenuItem *ClearLogPopupMenu;
  void __fastcall OptionsMenuClick(TObject *Sender);
  void __fastcall StartMenuClick(TObject *Sender);
  void __fastcall BrowseMenuClick(TObject *Sender);
  void __fastcall AboutMenuClick(TObject *Sender);
  void __fastcall ExitMenuClick(TObject *Sender);
  void __fastcall FormKeyUp(TObject *Sender, WORD &Key, TShiftState Shift);
  void __fastcall StopMenuClick(TObject *Sender);
  void __fastcall BrowseSpeedButtonClick(TObject *Sender);
  void __fastcall StartSpeedButtonClick(TObject *Sender);
  void __fastcall OptionsSpeedButtonClick(TObject *Sender);
  void __fastcall HelpSpeedButtonClick(TObject *Sender);
  void __fastcall StopSpeedButtonClick(TObject *Sender);
  void __fastcall ShowSpeedButtonsMenuClick(TObject *Sender);
  void __fastcall ShowStatusBarMenuClick(TObject *Sender);
  void __fastcall HelpSubMenuClick(TObject *Sender);
  void __fastcall ClearLogMenuClick(TObject *Sender);
  void __fastcall ClearLogPopupMenuClick(TObject *Sender);
private:	// User declarations
  TOptions *m_pOptions;
  TSearch *m_pSearch;
  TSlotTimer *m_pSlotTimer;

public:		// User declarations
  __fastcall TMainWindow(TComponent* Owner);
  __fastcall ~TMainWindow(void);
  void SetProgramState(EProgramState State);
  virtual void ShowProgress(int nEventType = 0, void *pEventData = 0);

protected:
  void SetOptions(void);
  AnsiString GetStatusBarText(EProgramState eState);
  AnsiString GetCaption(EProgramState eState);
  void AddLogEntryToProgressRichEdit(int nEventType, void *pEventData);
};
//---------------------------------------------------------------------------
extern PACKAGE TMainWindow *MainWindow;
//---------------------------------------------------------------------------
#endif
