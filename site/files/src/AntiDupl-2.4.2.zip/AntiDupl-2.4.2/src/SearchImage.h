/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
#ifndef __SearchImage_h__
#define __SearchImage_h__

#include <vcl.h>
#include "Options.h"
#include "SearchImageStruct.h"
#include <vector.h>
//-----------------------------------------------------------------------
class TShowProgress;
//-----------TSearch:----------------------------------------------------
class TSearch
{
public:
enum STATE   // Program state:
{
 WAIT = 0,   // Wait for new search;
 SEARCH = 1, // Search images;
 SCAN = 2,   // Scan images
 RESULT = 3  // Show search result;
};
enum EVENT
{
 E_None = 0,
 E_BeginSearch = 1,  
 E_BeginScan = 2,
 E_EndScan = 3,
 E_Stopped = 4,
 E_ShowResults = 5,
 E_ShowStatistic = 6
};

private:
 STATE m_eState;
 TOptions *m_pOptions;
 TStatistic m_CurrentSearchStatistic;
 std::vector<TCollectedData> m_Data;
 std::vector<TSearchResult> m_Result;
 int m_nCurrent;
 TShowProgress *m_pShowProgress;
 int m_nMaxFastSum;
 int m_nMaxSlowSum;

protected:
 void SearchImages(AnsiString sDirectory);
 void ScanImages(void);
 void ShowResult(void);
 bool SetImageData(TCollectedData *pData);
 void CheckOnDefect(TCollectedData *pData);
 void SetDefectCase(TCollectedData *pData);
 void CheckOnEquality(void);
 bool EqualImages(TCollectedData *pCurrent, TCollectedData *pData, int *pDifference);
 bool AutoDeleteEqual(TCollectedData *pCurrent, TCollectedData *pData, int nDifference);

 bool SupportedFormat(AnsiString sFileName);
 int GetKeySize(void);
 unsigned char GetGray(TColor Color);
 void DeleteImage(TImageInf *pImageInf);
 void ReplaceImage(TImageInf *pFromImageInf, TImageInf *pToImageInf);
public:
 TSearch(TShowProgress *pShowProgress);
 ~TSearch(void);

 void Execute(TOptions *pOptions);
 AnsiString CurentFileName(void) const;
 int Total(void) const;
 int Current(void) const {return m_nCurrent + 1;};
 void Stop(void);
 STATE State(void) {return m_eState;};
 const TStatistic& Statistic(void) const {return m_CurrentSearchStatistic;};
};
//-----------------------------------------------------------------------
#endif //__SearchImage_h__


 