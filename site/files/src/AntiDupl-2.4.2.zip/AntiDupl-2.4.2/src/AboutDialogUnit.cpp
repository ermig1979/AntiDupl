/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "AboutDialogUnit.h"
#include "GDIplusWrapper.h"
#include "Utils.h"
#include "Options.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TAboutDialog *AboutDialog;
//---------------------------------------------------------------------------
__fastcall TAboutDialog::TAboutDialog(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TAboutDialog::OkButtonClick(TObject *Sender)
{
 Close();  
}
//---------------------------------------------------------------------------
void TAboutDialog::Show(TOptions *pOptions)
{
 Caption = g_pStr->Get(9);
 AntiDuplLabel->Caption = "AntiDupl";
 AntiDuplLabel->Font->Size = 16;
 DataLabel->Caption = "2002 - 2009";
 if(pOptions->m_sLanguage == "Russian")
 {
  VersionLabel->Caption = "������ 2.4.2";
  PlaceLabel->Caption = "�����, ��������";
  AthorLabel->Caption = "�������� �����";
 }
 if(pOptions->m_sLanguage == "English")
 {
  VersionLabel->Caption = "Version 2.4.2";
  PlaceLabel->Caption = "Minsk, Belarus";
  AthorLabel->Caption = "Yermalayeu Ihar";
 }
 ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TAboutDialog::AdressLabelClick(TObject *Sender)
{
 ShellExecute(Handle, "open", "http://antidupl.narod.ru", NULL, NULL, SW_SHOWNORMAL);
}
//---------------------------------------------------------------------------
void __fastcall TAboutDialog::FormCreate(TObject *Sender)
{
 AnsiString aboutFileName = GetAppDir() + "pict\\About.jpg";
 if(!FileExists(aboutFileName))
 {
  ShowMessage("Can't find file 'pict\\About.jpg'!");
  abort();
 }
 TGDIplusImage *pImage = new TGDIplusImage();
 Graphics::TBitmap *pBitmap = new Graphics::TBitmap();
 if(!(pImage->Load(aboutFileName) && pImage->GetBitmap(pBitmap)))
 {
  ShowMessage("Can't open file 'pict\\About.jpg'!");
  abort();
 }
 AboutImage->Canvas->Draw(0, 0, pBitmap);
 AboutImage->Canvas->Pen->Color = clDkGray;
 AboutImage->Canvas->MoveTo(0, AboutImage->Height - 1);
 AboutImage->Canvas->LineTo(0, 0);
 AboutImage->Canvas->LineTo(AboutImage->Width - 1, 0);
 AboutImage->Canvas->Pen->Color = clWhite;
 AboutImage->Canvas->LineTo(AboutImage->Width - 1, AboutImage->Height - 1);
 AboutImage->Canvas->LineTo(0, AboutImage->Height - 1);
 delete pBitmap;
 delete pImage;
}
//---------------------------------------------------------------------------

