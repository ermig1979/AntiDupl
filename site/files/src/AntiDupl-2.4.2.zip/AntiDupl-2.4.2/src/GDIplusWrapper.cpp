/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
#pragma hdrstop

#include "GDIplusWrapper.h"
#include <algorithm>
using namespace std;
#include <windows.h>
#include <gdiplus.h>
#pragma comment (lib, "GDIPlus.lib")
//---------------class TGDIplus:-----------------------------------------
TGDIplus::TGDIplus(void)
{
 Gdiplus::GdiplusStartupInput gdiplusStartupInput;
 Gdiplus::GdiplusStartup(&m_GDIplusToken, &gdiplusStartupInput, NULL);
};
//-----------------------------------------------------------------------
TGDIplus::~TGDIplus(void)
{
 Gdiplus::GdiplusShutdown(m_GDIplusToken);
};
//---------------class TGDIplusImage:------------------------------------
TGDIplusImage::TGDIplusImage(void)
{
 m_pBitmap = NULL;
};
//-----------------------------------------------------------------------
TGDIplusImage::~TGDIplusImage(void)
{
 if(m_pBitmap != NULL)
  delete m_pBitmap;
};
//-----------------------------------------------------------------------
bool TGDIplusImage::Load(const AnsiString &sFileName)
{
 wchar_t* wFileName;
 wFileName = (wchar_t*)malloc(sFileName.WideCharBufSize()*sizeof(wchar_t));
 sFileName.WideChar(wFileName, sFileName.WideCharBufSize()); 
 if(m_pBitmap != NULL)
  delete m_pBitmap;
 try
 {
  m_pBitmap = new Gdiplus::Bitmap(wFileName);
 }
 catch(...)
 {
  if(m_pBitmap != NULL)
   delete m_pBitmap;
  m_pBitmap = NULL;
  ShowMessage("GDI+ can't open file " + sFileName);
 };
 if(GetFormat() == NON)
 {
  if(m_pBitmap != NULL)
   delete m_pBitmap;
  m_pBitmap = NULL;
 };
 free(wFileName);
 return (bool)m_pBitmap;
};
//-----------------------------------------------------------------------
bool TGDIplusImage::GetBitmap(Graphics::TBitmap *pBitmap) const
{
 if(m_pBitmap)
 {
  HBITMAP hBitmap;
  Gdiplus::Color clBackground = Gdiplus::Color(0, 0, 0);
  m_pBitmap->GetHBITMAP(clBackground, &hBitmap);
  pBitmap->ReleaseHandle();
  pBitmap->Handle = hBitmap;
 };
 return bool(m_pBitmap && pBitmap->Height && pBitmap->Width);
};
//-----------------------------------------------------------------------
bool TGDIplusImage::GetThumbnail(int nWidth, int nHeight, Graphics::TBitmap *pBitmap) const
{ 
 if(m_pBitmap)
 {
  Gdiplus::Bitmap *pThumbnail = (Gdiplus::Bitmap*)m_pBitmap->GetThumbnailImage(nWidth, nHeight, NULL, NULL);
  HBITMAP hBitmap;
  Gdiplus::Color clBackground = Gdiplus::Color(0, 0, 0);
  pThumbnail->GetHBITMAP(clBackground, &hBitmap);
  pBitmap->ReleaseHandle();
  pBitmap->Handle = hBitmap;
  delete pThumbnail;
 };
 return bool(m_pBitmap && pBitmap->Height && pBitmap->Width);
};
//-----------------------------------------------------------------------
TGDIplusImage::FORMAT TGDIplusImage::GetFormat(void) const
{
 if(!m_pBitmap) return NON;
 GUID guid;
 m_pBitmap->GetRawFormat(&guid);
 if(guid == Gdiplus::ImageFormatJPEG)
  return JPG;
 else if(guid == Gdiplus::ImageFormatGIF)
  return GIF;
 else if(guid == Gdiplus::ImageFormatBMP)
  return BMP;
 else if(guid == Gdiplus::ImageFormatPNG)
  return PNG;
 else if(guid == Gdiplus::ImageFormatTIFF)
  return TIF;
 else
  return NON;
};
//-----------------------------------------------------------------------
int TGDIplusImage::Height(void) const
{
 if(!m_pBitmap) return 0;
 return m_pBitmap->GetHeight();
};
//-----------------------------------------------------------------------
int TGDIplusImage::Width(void) const
{
 if(!m_pBitmap) return 0;
 return m_pBitmap->GetWidth();
};
//-----------------------------------------------------------------------

