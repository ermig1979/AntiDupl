/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainWindowUnit.h"
#include "OptionsDialogUnit.h"
#include "Options.h"
#include "GDIplusWrapper.h"
#include "SearchImage.h"
#include "Utils.h"
#include "BrowseFolderDialog.h"
#include "AboutDialogUnit.h"
#include "MistakeDataBase.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMainWindow *MainWindow;
//---------------------------------------------------------------------------
__fastcall TMainWindow::TMainWindow(TComponent* Owner)
        : TForm(Owner)
{
  m_pOptions = new TOptions(GetAppDir() + "AntiDupl.ini");
  if(!FileExists(GetAppDir() + "AntiDupl.lng"))
  {
   ShowMessage("Can't find file 'AntiDupl.lng'!");
   abort();
  }

  g_pMistakeDataBase = new TMistakeDataBase();
  try
  {
   g_pMistakeDataBase->Load(GetAppDir() + "AntiDupl.mdb");
  }
  catch(...)
  {
   g_pMistakeDataBase->Clear();
  }
  
  g_pStr = new TStringStorage(GetAppDir() + "AntiDupl.lng");
  g_pStr->Load(m_pOptions->m_sLanguage);
  m_pSearch = new TSearch(this);
  m_pSlotTimer = new TSlotTimer(20);
  ProgressRichEdit->Clear();
  ShowSpeedButtonsMenu->Checked = m_pOptions->m_bShowSpeedButtons;
  ToolBar->Visible = m_pOptions->m_bShowSpeedButtons;
  ShowStatusBarMenu->Checked = m_pOptions->m_bShowStatusBar;
  StatusBar->Visible = m_pOptions->m_bShowStatusBar;
  SetOptions();
}
//---------------------------------------------------------------------------
__fastcall TMainWindow::~TMainWindow(void)
{
  m_pOptions->Save(GetAppDir() + "AntiDupl.ini");
  ProgressRichEdit->PlainText = true;
  ProgressRichEdit->Lines->SaveToFile(GetAppDir() + "AntiDupl.log");
  delete g_pStr;
  delete m_pSearch;
  if(g_pMistakeDataBase)
  {
   if(m_pOptions)
    g_pMistakeDataBase->Save(GetAppDir() + "AntiDupl.mdb");
   delete g_pMistakeDataBase;
  }
  delete m_pOptions;
  delete m_pSlotTimer;
}
//---------------------------------------------------------------------------
void __fastcall TMainWindow::OptionsMenuClick(TObject *Sender)
{
  OptionsDialog->Execute(m_pOptions);
  SetOptions();
}
//---------------------------------------------------------------------------
void __fastcall TMainWindow::StartMenuClick(TObject *Sender)
{
  SetProgramState(PS_RUN);
  m_pSearch->Execute(m_pOptions);
  SetProgramState(PS_STOP);
}
//---------------------------------------------------------------------------
void TMainWindow::SetProgramState(EProgramState State)
{
 switch(State)
 {
  case PS_STOP:
   Application->Icon->Handle = LoadIcon(HInstance, "GREEN");
   MainWindow->Icon->Handle = LoadIcon(HInstance, "GREEN");
   FileMenu->Visible = true;
   StopMenu->Visible = false;
   ToolsMenu->Visible = true;
   HelpMenu->Visible = true;
   ViewMenu->Visible = true;
   StopSpeedButton->Enabled = false;
   StartSpeedButton->Enabled = true;
   BrowseSpeedButton->Enabled = true;
   OptionsSpeedButton->Enabled = true;
   HelpSpeedButton->Enabled = true;
   ProgressBar->Position = 0;
   break;
  case PS_RUN:
   Application->Icon->Handle = LoadIcon(HInstance, "YELLOW");
   MainWindow->Icon->Handle = LoadIcon(HInstance, "YELLOW");
   FileMenu->Visible = false;
   StopMenu->Visible = true;
   ToolsMenu->Visible = false;
   HelpMenu->Visible = false;
   ViewMenu->Visible = false;
   StopSpeedButton->Enabled = true;
   StartSpeedButton->Enabled = false;
   BrowseSpeedButton->Enabled = false;
   OptionsSpeedButton->Enabled = false;
   HelpSpeedButton->Enabled = false;
   break;
  case PS_FOUND:
   Application->Icon->Handle = LoadIcon(HInstance, "RED");
   MainWindow->Icon->Handle = LoadIcon(HInstance, "RED");
   break;
 }
 StatusBar->SimpleText = GetStatusBarText(State);
 Application->Title = GetCaption(State);
 MainWindow->Caption = Application->Title;
}
//---------------------------------------------------------------------------
void __fastcall TMainWindow::BrowseMenuClick(TObject *Sender)
{
 SelectFolder(g_pStr->Get(0), m_pOptions->m_sDirectoryName, MainWindow->Handle);
 SetProgramState(PS_STOP);
}
//---------------------------------------------------------------------------
void __fastcall TMainWindow::AboutMenuClick(TObject *Sender)
{
 AboutDialog->Show(m_pOptions);
}
//---------------------------------------------------------------------------
void __fastcall TMainWindow::ExitMenuClick(TObject *Sender)
{
 Close();  
}
//---------------------------------------------------------------------------
void TMainWindow::ShowProgress(int nEventType, void *pEventData)
{
 if(nEventType)
  AddLogEntryToProgressRichEdit(nEventType, pEventData);
 if(m_pSlotTimer->TimeChanged())
 {
  int nProcent = 0;
  if(m_pSearch->Total())
   nProcent = m_pSearch->Current()*100/m_pSearch->Total();
  ProgressBar->Position = nProcent;
  StatusBar->SimpleText = GetStatusBarText(PS_RUN);
  Application->Title = GetCaption(PS_RUN);
  MainWindow->Caption = Application->Title;
  Application->ProcessMessages();
 }
};
//---------------------------------------------------------------------------
void TMainWindow::SetOptions(void)
{
 FileMenu->Caption = g_pStr->Get(1);
 ToolsMenu->Caption = g_pStr->Get(2);
 HelpMenu->Caption = g_pStr->Get(3);
 HelpSubMenu->Caption = g_pStr->Get(3);
 HelpSpeedButton->Hint = g_pStr->Get(3);
 OptionsMenu->Caption = g_pStr->Get(4);
 OptionsSpeedButton->Hint = g_pStr->Get(4);
 StartMenu->Caption = g_pStr->Get(5);
 StartSpeedButton->Hint = g_pStr->Get(5);
 BrowseMenu->Caption = g_pStr->Get(6);
 BrowseSpeedButton->Hint = g_pStr->Get(6);
 ExitMenu->Caption = g_pStr->Get(7);
 AboutMenu->Caption = g_pStr->Get(9) + "...";
 StopMenu->Caption = g_pStr->Get(10);
 StopSpeedButton->Hint = g_pStr->Get(10);
 ViewMenu->Caption = g_pStr->Get(11);
 ShowSpeedButtonsMenu->Caption = g_pStr->Get(12);
 ShowStatusBarMenu->Caption = g_pStr->Get(13);
 ClearLogMenu->Caption = g_pStr->Get(64);
 ClearLogPopupMenu->Caption = g_pStr->Get(64);
 SetProgramState(PS_STOP);
};
//---------------------------------------------------------------------------
 void __fastcall TMainWindow::FormKeyUp(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
 switch(Key)
 {
 case VK_PAUSE:
  m_pSearch->Stop();
  break;
 }
}
//---------------------------------------------------------------------------
void __fastcall TMainWindow::StopMenuClick(TObject *Sender)
{
 m_pSearch->Stop();
}
//---------------------------------------------------------------------------
void __fastcall TMainWindow::BrowseSpeedButtonClick(TObject *Sender)
{
 BrowseMenuClick(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TMainWindow::StartSpeedButtonClick(TObject *Sender)
{
 if(m_pSearch->State())
  StopMenuClick(Sender);
 else
  StartMenuClick(Sender);
};
//---------------------------------------------------------------------------
void __fastcall TMainWindow::OptionsSpeedButtonClick(TObject *Sender)
{
 OptionsMenuClick(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TMainWindow::HelpSpeedButtonClick(TObject *Sender)
{
 HelpSubMenuClick(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TMainWindow::StopSpeedButtonClick(TObject *Sender)
{
 StopMenuClick(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TMainWindow::ShowSpeedButtonsMenuClick(TObject *Sender)
{
 if(ShowSpeedButtonsMenu->Checked)
 {
  ShowSpeedButtonsMenu->Checked = false;
  m_pOptions->m_bShowSpeedButtons = false;
  ToolBar->Visible = false;
 }
 else
 {
  ShowSpeedButtonsMenu->Checked = true;
  m_pOptions->m_bShowSpeedButtons = true;
  ToolBar->Visible = true;
 }
}
//---------------------------------------------------------------------------
void __fastcall TMainWindow::ShowStatusBarMenuClick(TObject *Sender)
{
 if(ShowStatusBarMenu->Checked)
 {
  ShowStatusBarMenu->Checked = false;
  m_pOptions->m_bShowStatusBar = false;
  StatusBar->Visible = false;
 }
 else
 {
  ShowStatusBarMenu->Checked = true;
  m_pOptions->m_bShowStatusBar = true;
  ProgressBar->Visible = false;
  StatusBar->Visible = true;
  ProgressBar->Visible = true;
 }
}
//---------------------------------------------------------------------------
AnsiString TMainWindow::GetStatusBarText(EProgramState eState)
{
 AnsiString sResult;
 if(StatusBar->Visible)
  switch(eState)
  {
  case PS_STOP:
   sResult = g_pStr->Get(14);
   break;
  case PS_RUN:
   switch(m_pSearch->State())
   {
   case TSearch::SEARCH:
    sResult = g_pStr->Get(15) + ". " +
     IntToStr(m_pSearch->Statistic().m_nSearchedImagesNumber) +
     " " + g_pStr->Get(16) + " " +
     IntToStr(m_pSearch->Statistic().m_nScanedFoldersNumber) +
     " " + g_pStr->Get(17);
    break;
   case TSearch::SCAN:
    sResult = g_pStr->Get(18) +
     IntToStr(m_pSearch->Current()) +
     " " + g_pStr->Get(19) + " " +
     IntToStr(m_pSearch->Total()) +
     ") - " +
     m_pSearch->CurentFileName();
    break;
   case TSearch::RESULT:
    break;
   }
   break;
  case PS_FOUND:
   sResult = g_pStr->Get(20);
   break;
  }
 return sResult;
}
//---------------------------------------------------------------------------
AnsiString TMainWindow::GetCaption(EProgramState eState)
{
 AnsiString sResult = "Antidupl - ";
 int nProcent = 0;
 if(m_pSearch->Total())
  nProcent = m_pSearch->Current()*100/m_pSearch->Total();
 switch(eState)
 {
 case PS_STOP:
  sResult += g_pStr->Get(21) + " - ";
  break;
 case PS_RUN:
  switch(m_pSearch->State())
  {
  case TSearch::SEARCH:
   sResult += g_pStr->Get(15) + " - ";
   break;
  case TSearch::SCAN:
   sResult += g_pStr->Get(22) + " - ";
   break;
  case TSearch::RESULT:
   sResult += g_pStr->Get(23) + " - ";
   break;
  }
  break;
 case PS_FOUND:
  sResult += g_pStr->Get(24) + " - ";
  break;
 }
 if((m_pSearch->State() != TSearch::SEARCH) && (eState != PS_STOP))
  sResult += IntToStr(nProcent) + g_pStr->Get(25) + " - ";
 sResult += m_pOptions->m_sDirectoryName;
 return sResult;
}
//---------------------------------------------------------------------------
void TMainWindow::AddLogEntryToProgressRichEdit(int nEventType, void *pEventData)
{
 ProgressRichEdit->Paragraph->FirstIndent = 10;
 TColor TempColor;
 switch(TSearch::EVENT(nEventType))
 {
  case TSearch::E_BeginSearch:
   ProgressRichEdit->Lines->Add("");
   ProgressRichEdit->SelAttributes->Style = ProgressRichEdit->SelAttributes->Style << fsBold;
   ProgressRichEdit->Paragraph->Alignment = taCenter;
   ProgressRichEdit->Lines->Add(g_pStr->Get(46));
   ProgressRichEdit->Paragraph->Alignment = taLeftJustify;
   ProgressRichEdit->Lines->Add(g_pStr->Get(47) + " " + GetDataAndTime());
   ProgressRichEdit->Lines->Add(g_pStr->Get(48) + " " + m_pOptions->m_sDirectoryName);
   ProgressRichEdit->Lines->Add("");
   ProgressRichEdit->Lines->Add(g_pStr->Get(49));
   break;
  case TSearch::E_BeginScan:
   ProgressRichEdit->Lines->Add(g_pStr->Get(50));
   ProgressRichEdit->Lines->Add(IntToStr(m_pSearch->Statistic().m_nSearchedImagesNumber) +
    " " + g_pStr->Get(51) + " " + IntToStr(m_pSearch->Statistic().m_nScanedFoldersNumber) +
    " " + g_pStr->Get(52));
   ProgressRichEdit->Lines->Add("");
   ProgressRichEdit->Lines->Add(g_pStr->Get(53));
   break;
  case TSearch::E_EndScan:
   ProgressRichEdit->Lines->Add(g_pStr->Get(54));
   ProgressRichEdit->Lines->Add(IntToStr(m_pSearch->Statistic().m_nScanedImagesNumber) +
    " " + g_pStr->Get(55));
   ProgressRichEdit->Lines->Add("");
   break;
  case TSearch::E_Stopped:
   TempColor = ProgressRichEdit->SelAttributes->Color;
   ProgressRichEdit->SelAttributes->Color = clRed;
   ProgressRichEdit->Lines->Add("\t" + g_pStr->Get(56));
   ProgressRichEdit->SelAttributes->Color = TempColor;
   break;
  case TSearch::E_ShowResults:
   ProgressRichEdit->Lines->Add(IntToStr(m_pSearch->Statistic().m_nResultsNumber) +
    " " + g_pStr->Get(57));
   ProgressRichEdit->Lines->Add("");
   break;
  case TSearch::E_ShowStatistic:
   ProgressRichEdit->Lines->Add(IntToStr(m_pSearch->Statistic().m_nDeletedImagesNumber) +
    " (" + IntToStr(m_pSearch->Statistic().m_nDeletedImagesSize/1024) +
    " kb) " + g_pStr->Get(58));
   ProgressRichEdit->Lines->Add("");
   break;
 }
}
//---------------------------------------------------------------------------
void __fastcall TMainWindow::HelpSubMenuClick(TObject *Sender)
{
 if(m_pOptions->m_sLanguage == "Russian")
  ShellExecute(Handle, "open", "Read me(rus).html", NULL, NULL, SW_SHOWNORMAL);
 if(m_pOptions->m_sLanguage == "English")
  ShellExecute(Handle, "open", "Read me(rus).html", NULL, NULL, SW_SHOWNORMAL); 
}
//---------------------------------------------------------------------------
void __fastcall TMainWindow::ClearLogMenuClick(TObject *Sender)
{
  ProgressRichEdit->Clear();
}
//---------------------------------------------------------------------------
void __fastcall TMainWindow::ClearLogPopupMenuClick(TObject *Sender)
{
 ClearLogMenuClick(Sender);
}
//---------------------------------------------------------------------------

