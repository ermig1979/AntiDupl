/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
#define NO_WIN32_LEAN_AND_MEAN
#include <shlobj.h>
#include <Filectrl.hpp>
#include "BrowseFolderDialog.h"
#include "Utils.h"
//-------------------- Select Folder -------------------------------------------
static int CALLBACK BrowseCallbackProc(HWND hWnd, UINT uMsg, LPARAM lParam, LPARAM lpData)
{
 switch (uMsg)
 {
  case BFFM_INITIALIZED:
   if (lpData) SendMessage(hWnd,BFFM_SETSELECTION,WPARAM(true),lpData);
   break;
  case BFFM_SELCHANGED:
   LPITEMIDLIST(lParam);
   break;
 };
 return 0;
};
//------------------------------------------------------------------------------
bool SelectFolder(const AnsiString &sCaption, AnsiString& Path, HWND hWndOwner)
{
 char TempPath[MAX_PATH];
 BROWSEINFO BrowseInfo;
 ZeroMemory(&BrowseInfo, sizeof(BrowseInfo));
 BrowseInfo.hwndOwner = hWndOwner;
 BrowseInfo.pidlRoot = NULL;
 BrowseInfo.pszDisplayName = NULL;
 BrowseInfo.lpszTitle = sCaption.c_str();
 BrowseInfo.ulFlags = BIF_RETURNONLYFSDIRS;
 BrowseInfo.lpfn = BrowseCallbackProc;
 BrowseInfo.lParam = LPARAM(Path.c_str());
 BrowseInfo.iImage = NULL;
 SHGetPathFromIDList(SHBrowseForFolder(&BrowseInfo), TempPath);
 if(DirExists(TempPath))
 {
  Path = TempPath;
 };
 return true;
};
//------------------------------------------------------------------------------
