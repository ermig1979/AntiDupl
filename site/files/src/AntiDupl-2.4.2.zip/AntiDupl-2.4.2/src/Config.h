/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
#ifndef __Config_h__
#define __Config_h__

//---------------------------------------------------------------------------
const int PIXELS_SIZE = 32;
const int RATIO_RESOLUTION = 32;
const int RATIO_DIFFERENCE = 1;
const int COMPARE_ORDER_VALUE = 8;

const unsigned int DIFF_DB_MAX_NEW_SIZE = 64;
//---------------------------------------------------------------------------
#endif// __Config_h__

 