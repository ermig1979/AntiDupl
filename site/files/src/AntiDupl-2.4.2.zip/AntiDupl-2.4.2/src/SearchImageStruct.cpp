/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
#include "SearchImageStruct.h"
//------------TFileInf:---------------------------------------------------------
TFileInf& TFileInf::operator=(const TFileInf& a)
{
 m_sFileName = a.m_sFileName;
 m_nFileSize = a.m_nFileSize;
 m_nFileTime = a.m_nFileTime;
 return *this;
}

bool TFileInf::operator==(const TFileInf &a) const
{
 return
  (m_sFileName == a.m_sFileName &&
   m_nFileSize == a.m_nFileSize &&
   m_nFileTime == a.m_nFileTime);
}

bool TFileInf::operator>(const TFileInf &a) const
{
 return (m_sFileName > a.m_sFileName);
}

bool TFileInf::operator<(const TFileInf &a) const
{
 return (m_sFileName < a.m_sFileName);
}

bool TFileInf::Load(FILE* in)
{
 size_t was_read, fileNameSize;
 char fileName[MAX_PATH];

 was_read = fread(&fileNameSize, sizeof(size_t), 1, in);
 if ( was_read < 1)
  return false;
 if (fileNameSize > MAX_PATH)
  return false;

 was_read = fread(&fileName, fileNameSize, 1, in);
 if (was_read < 1)
  return false;
 m_sFileName = fileName;

 was_read = fread(&m_nFileSize, sizeof(int), 1, in);
 if ( was_read < 1)
  return false;

 was_read = fread(&m_nFileTime, sizeof(int), 1, in);
 if ( was_read < 1)
  return false;

 return true;
}

bool TFileInf::Save(FILE* out) const
{
 size_t was_write, fileNameSize;

 fileNameSize = m_sFileName.Length() + 1;
 if (fileNameSize > MAX_PATH)
  return false;
 was_write = fwrite(&fileNameSize, sizeof(size_t), 1, out);
 if (was_write < 1)
  return false;

 was_write = fwrite(m_sFileName.c_str(), fileNameSize, 1, out);
 if (was_write < 1)
  return false;

 was_write = fwrite(&m_nFileSize, sizeof(int), 1, out);
 if (was_write < 1)
  return false;

 was_write = fwrite(&m_nFileTime, sizeof(int), 1, out);
 if (was_write < 1)
  return false;

 return true;
}
//-----------TImageInf:---------------------------------------------------------
TImageInf& TImageInf::operator=(const TImageInf& a)
{
 *(static_cast<TFileInf*>(this)) = a;
 m_eImageFormat = a.m_eImageFormat;
 m_nImageHeight = a.m_nImageHeight;
 m_nImageWidth = a.m_nImageWidth;
 return *this;
}
//------------TCollectedData:---------------------------------------------------
TCollectedData::TCollectedData(int nSize)
 :m_nSize(nSize),
 m_nRatio(0)
{
 m_pKey = malloc(m_nSize);
}

TCollectedData::TCollectedData(const TCollectedData& a)
 :TImageInf(a),
 m_nSize(a.m_nSize),
 m_nRatio(a.m_nRatio)
{
 m_pKey = malloc(m_nSize);
 memcpy(m_pKey, a.m_pKey, m_nSize);
}

TCollectedData::~TCollectedData(void)
{
 free(m_pKey);
}

TCollectedData& TCollectedData::operator=(const TCollectedData& a)
{
 *(static_cast<TImageInf*>(this)) = a;
 if(m_nSize != a.m_nSize)
 {
  m_nSize = a.m_nSize;
  free(m_pKey);
  m_pKey = malloc(m_nSize);
 }
 memcpy(m_pKey, a.m_pKey, m_nSize);
 m_nRatio = a.m_nRatio;
 return *this;
}
//-----------TSearchResult:-----------------------------------------------------
TSearchResult& TSearchResult::operator=(const TSearchResult& a)
{
 m_eType = a.m_eType;
 m_Left = a.m_Left;
 m_Right = a.m_Right;
 return *this;
}
//-----------TStatistic:--------------------------------------------------------
void TStatistic::Clear(void)
{
 m_nScanedFoldersNumber = 0;
 m_nSearchedImagesNumber = 0;
 m_nScanedImagesNumber = 0;
 m_nDeletedImagesNumber = 0;
 m_nDeletedImagesSize = 0;
 m_nResultsNumber = 0;
}

TStatistic& TStatistic::operator= (const TStatistic& s)
{
 m_nScanedFoldersNumber = s.m_nScanedFoldersNumber;
 m_nSearchedImagesNumber = s.m_nSearchedImagesNumber;
 m_nScanedImagesNumber = s.m_nScanedImagesNumber;
 m_nDeletedImagesNumber = s.m_nDeletedImagesNumber;
 m_nDeletedImagesSize = s.m_nDeletedImagesSize;
 m_nResultsNumber = s.m_nResultsNumber;
 return *this;
}
//------------------------------------------------------------------------------ 