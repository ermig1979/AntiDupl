/*
AntiDupl-2.4.2
Yermalayeu Ihar 
Minsk, Belarus 
2002-2009
http://antidupl.narod.ru
*/
#ifndef DeleteDialogUnit2H
#define DeleteDialogUnit2H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TOptions;
class TImageInf;
//---------------------------------------------------------------------------
class TDeleteDialog2 : public TForm
{
__published:	// IDE-managed Components
  TBevel *Bevel;
  TImage *Image;
  TButton *DeleteButton;
  TButton *StopButton;
  TButton *NextButton;
  TCheckBox *QueryDuringSearch;
  TLabel *FileNameLabel;
  TLabel *FileSizeLabel;
  TLabel *ImageSizeLabel;
  TPopupMenu *PopupMenu;
  TMenuItem *CopyPathPopupMenuItem;
  TMenuItem *OpenPicturePopupMenuItem;
  TButton *MistakeButton;
  void __fastcall NextButtonClick(TObject *Sender);
  void __fastcall DeleteButtonClick(TObject *Sender);
  void __fastcall StopButtonClick(TObject *Sender);
  void __fastcall FormResize(TObject *Sender);
  void __fastcall FormKeyUp(TObject *Sender, WORD &Key, TShiftState Shift);
  void __fastcall OpenPicturePopupMenuItemClick(TObject *Sender);
  void __fastcall CopyPathPopupMenuItemClick(TObject *Sender);
  void __fastcall MistakeButtonClick(TObject *Sender);
  void __fastcall ImageDblClick(TObject *Sender);
public:
  enum EResult
  {
   NEXT = 0,
   STOP = 1,
   DEL = 2,
   MISTAKE = 3
  };
private:	// User declarations
  EResult m_eResult;
  Graphics::TBitmap *m_pBitmap;
  TOptions *m_pOptions;
public:		// User declarations
  __fastcall TDeleteDialog2(TComponent* Owner);
  EResult Show(TOptions *pOptions, TImageInf *pData);
};
//---------------------------------------------------------------------------
extern PACKAGE TDeleteDialog2 *DeleteDialog2;
//---------------------------------------------------------------------------
#endif
