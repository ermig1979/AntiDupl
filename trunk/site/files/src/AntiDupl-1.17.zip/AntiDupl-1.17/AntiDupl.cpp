/*
AntiDupl-1.17
Yermalayeu Ihar 
Minsk, Belarus 
2002-2005
http://antidupl.narod.ru
*/
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USEFORM("Main_Form_Unit.cpp", Main_Form);
USEFORM("Compare_Dialog_Unit.cpp", Compare_Dialog);
USEFORM("Delete_Dialog_Unit.cpp", Delete_Dialog);
USERES("AntiDupl.res");
USEUNIT("Common_Units\Graph_Unit.cpp");
USEUNIT("Common_Units\Dialog_Unit.cpp");
USEUNIT("Common_Units\File_Unit.cpp");
USEUNIT("Option_Unit.cpp");
USEUNIT("Search_Unit.cpp");
USEFORM("About_Dialog_Unit.cpp", About_Dialog);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->Title = "AntiDupl";
                 Application->CreateForm(__classid(TMain_Form), &Main_Form);
                 Application->CreateForm(__classid(TCompare_Dialog), &Compare_Dialog);
                 Application->CreateForm(__classid(TDelete_Dialog), &Delete_Dialog);
                 Application->CreateForm(__classid(TAbout_Dialog), &About_Dialog);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
