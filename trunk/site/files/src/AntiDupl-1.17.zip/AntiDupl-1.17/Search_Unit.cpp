/*
AntiDupl-1.17
Yermalayeu Ihar 
Minsk, Belarus 
2002-2005
http://antidupl.narod.ru
*/
#include <jpeg.hpp>
#include "Delete_Dialog_Unit.h"
#include "Compare_Dialog_Unit.h"
#include "Common_Units\File_Unit.h"
#include "Search_Unit.h"
//------------------------------------------------------------------------------
__fastcall TSearchJpegFile::TSearchJpegFile(void)
{
Log=new TSearchLog();
PresentNamberFile=0;
BoolRun=false;
TotalAmountFile=0;
FileInf=NULL;
};
//------------------------------------------------------------------------------
__fastcall TSearchJpegFile::~TSearchJpegFile(void)
{
delete Log;
};
//------------------------------------------------------------------------------
int TSearchJpegFile::GetTotalAmountFile(void)
{
if (BoolRun)return TotalAmountFile;
else return 0;
};
//------------------------------------------------------------------------------
int TSearchJpegFile::GetPresentNamberFile(void)
{
if (BoolRun)return PresentNamberFile;
else return 0;
};
//------------------------------------------------------------------------------
AnsiString TSearchJpegFile::GetPresentFileName(void)
{
if(PresentNamberFile>0)
{
 AnsiString temp=FileInf[PresentNamberFile-1].Name;
 temp.Delete(1,Log->DirectoryName.Length());
 return "..."+temp;
}
else return "";
};
//------------------------------------------------------------------------------
void __fastcall TSearchJpegFile::Search(void)
{
 BoolRun=true;
 TotalAmountFile=0;
 PresentNamberFile=0;
 SearchNamberFile(Log->DirectoryName);
 FileInf=new TFileInf[TotalAmountFile];
 for(int i=0;i<TotalAmountFile;i++)FileInf[i].Exist=false;
 SearchFileInf(Log->DirectoryName);
 TotalAmountFile=0;
 PresentNamberFile=0;
 delete[] FileInf;
 BoolRun=false;
};
//------------------------------------------------------------------------------
void __fastcall TSearchJpegFile::SearchNamberFile(AnsiString DirectoryName)
{
 TSearchRec SJF;
 SetCurrentDir(DirectoryName);
 AnsiString temp;
 if ((FindFirst("*",faAnyFile,SJF)==0)&&BoolRun)
 {
  if(DirectoryName.Length()==3)temp=DirectoryName+SJF.Name;
  else temp=DirectoryName+"\\"+SJF.Name;
  if((CompareText(ExtractFileExt(temp),".jpg")==0)||
     (CompareText(ExtractFileExt(temp),".jpeg")==0))
  {
   TotalAmountFile++;
   ShowProcess();
//   FileSetAttr(SJF.Name, FileGetAttr(SJF.Name)& !faHidden);
  }
  else if(((SJF.Attr&faDirectory)>0)&&(SJF.Name!=".")&&(SJF.Name!="..")&&Log->SubDirectories)
  {
   SearchNamberFile(temp);
  };
  while ((FindNext(SJF)==0)&&BoolRun)
  {
   if(DirectoryName.Length()==3)temp=DirectoryName+SJF.Name;
   else temp=DirectoryName+"\\"+SJF.Name;
   if((CompareText(ExtractFileExt(temp),".jpg")==0)||
      (CompareText(ExtractFileExt(temp),".jpeg")==0))
   {
    TotalAmountFile++;
    ShowProcess();
//    FileSetAttr(SJF.Name, FileGetAttr(SJF.Name)& !faHidden);
   }
   else if(((SJF.Attr&faDirectory)>0)&&(SJF.Name!=".")&&(SJF.Name!="..")&&Log->SubDirectories)
   {
    SearchNamberFile(temp);
   };
  };
 };
 FindClose(SJF);

};
//------------------------------------------------------------------------------
void __fastcall TSearchJpegFile::SearchFileInf(AnsiString DirectoryName)
{
 TSearchRec SJF;
 AnsiString temp;
 int iFileHandle, i;
 char *Char=new char [3];
 SetCurrentDir(DirectoryName);
 if ((FindFirst("*", faAnyFile,SJF)==0)&&BoolRun&&(PresentNamberFile<TotalAmountFile))
 {
  if(DirectoryName.Length()==3)temp=DirectoryName+SJF.Name;
  else temp=DirectoryName+"\\"+SJF.Name;
  if((CompareText(ExtractFileExt(temp),".jpg")==0)||
     (CompareText(ExtractFileExt(temp),".jpeg")==0))
  {
   FileInf[PresentNamberFile].Name=temp;
   FileInf[PresentNamberFile].Exist=true;
   FileInf[PresentNamberFile].Size=SJF.Size;
   if(Log->CheckOnDefect)CheckOnDefect();
   if(Log->CheckOnEquality)CheckOnEquality();
   PresentNamberFile++;
   ShowProcess();
  }
  else if(((SJF.Attr&faDirectory)>0)&&(SJF.Name!=".")&&(SJF.Name!="..")&&Log->SubDirectories)
  {
   SearchFileInf(temp);
  };
  while ((FindNext(SJF)==0)&&BoolRun&&(PresentNamberFile<TotalAmountFile))
  {
   if(DirectoryName.Length()==3)temp=DirectoryName+SJF.Name;
   else temp=DirectoryName+"\\"+SJF.Name;
   if((CompareText(ExtractFileExt(temp),".jpg")==0)||
      (CompareText(ExtractFileExt(temp),".jpeg")==0))
   {
    FileInf[PresentNamberFile].Name=temp;
    FileInf[PresentNamberFile].Exist=true;
    FileInf[PresentNamberFile].Size=SJF.Size;
    iFileHandle=FileOpen(FileInf[PresentNamberFile].Name,fmOpenRead);
    if(iFileHandle>=0)
    {
     FileSeek(iFileHandle,0,0);
     FileRead(iFileHandle,Char,3);
    }
    else
    {
     for(i=0;i<3;i++)Char[i]=' ';
    };
    FileClose(iFileHandle);
    if((Char[0]!='�')||(Char[1]!='�')||(Char[2]!='�'))
      FileInf[PresentNamberFile].Exist=false;
    if((Log->CheckOnDefect)&&(FileInf[PresentNamberFile].Exist))CheckOnDefect();
    if((Log->CheckOnEquality)&&(FileInf[PresentNamberFile].Exist))CheckOnEquality();
    PresentNamberFile++;
    ShowProcess();
   }
   else if(((SJF.Attr&faDirectory)>0)&&(SJF.Name!=".")&&(SJF.Name!="..")&&Log->SubDirectories)
   {
    SearchFileInf(temp);
   };
  };
 };
 FindClose(SJF);
};
//------------------------------------------------------------------------------
void __fastcall TSearchJpegFile::CheckOnEquality(void)
{
int i, i1, i2, Sum, Deff,
    FastSum=NPix*Log->CompareOder*Log->CompareOder,
    SlowSum=NPix*NPix*Log->CompareOder*Log->CompareOder;
 Graphics::TBitmap *Bitmap1=new Graphics::TBitmap();
 TJPEGImage *Jpeg1=new TJPEGImage();
 try
 {
  Jpeg1->LoadFromFile(FileInf[PresentNamberFile].Name);
  Jpeg1->Grayscale=true;
  if(Log->FullPicture)Jpeg1->Scale=jsFullSize; else Jpeg1->Scale=jsEighth;
  Bitmap1->Assign(Jpeg1);
  FileInf[PresentNamberFile].Height=Jpeg1->Height;
  FileInf[PresentNamberFile].Width=Jpeg1->Width;
  for(i1=0;i1<NPix;i1++)
  {
   for(i2=0;i2<NPix;i2++)
   {
    FileInf[PresentNamberFile].ComparePixels[i1][i2]=
     Bitmap1->Canvas->Pixels[i1*Bitmap1->Width/NPix]
     [i2*Bitmap1->Height/NPix]/0x00010101;
    };
  };
  for(i=0;i<PresentNamberFile;i++)
  {
   if(FileInf[i].Exist&&((!Log->SizeControl)||((FileInf[PresentNamberFile].Height==FileInf[i].Height)&&
      (FileInf[PresentNamberFile].Width==FileInf[i].Width))))
   {
    Sum=0;
    for(int i1=2;i1<NPix;i1+=4)
    {
     Deff=FileInf[PresentNamberFile].ComparePixels[i1][i1]-FileInf[i].ComparePixels[i1][i1];
     Sum+=Deff*Deff;
     Deff=FileInf[PresentNamberFile].ComparePixels[i1][NPix-i1]-FileInf[i].ComparePixels[i1][NPix-i1];
     Sum+=Deff*Deff;
    };
    if(Sum<=FastSum)
    {
     Sum=0;
     for(int i1=0;i1<NPix;i1++)
     {
      for(int i2=0;i2<NPix;i2++)
      {
       Deff=FileInf[PresentNamberFile].ComparePixels[i1][i2]-FileInf[i].ComparePixels[i1][i2];
       Sum+=Deff*Deff;
      };
     };
     if((Log->AutoDeleteEqual)&&
        (Sum==0)&&
        (FileInf[PresentNamberFile].Height==FileInf[i].Height)&&
        (FileInf[PresentNamberFile].Width==FileInf[i].Width))
     {
      FileDelete(FileInf[PresentNamberFile].Name,Log->DeleteToRecycleBin);
      FileSetAttr(FileInf[PresentNamberFile].Name,
                  FileGetAttr(FileInf[PresentNamberFile].Name)&
                  !faHidden||!faArchive||!faReadOnly||!faSysFile);
      FileInf[PresentNamberFile].Exist=false;
      goto Quit;
     };
     if((Sum<=SlowSum)&&FileInf[PresentNamberFile].Exist)
     {
      switch (Compare_Dialog->Show(Log, FileInf[i].Name, FileInf[PresentNamberFile].Name))
      {
       case 1: Stop();break;
       case 2:
       {
        FileDelete(FileInf[i].Name,Log->DeleteToRecycleBin);
        FileInf[i].Exist=false;
       };break;
       case 3:
       {
        FileDelete(FileInf[PresentNamberFile].Name,Log->DeleteToRecycleBin);
        FileInf[PresentNamberFile].Exist=false;
        goto Quit;
       };break;
       default :;
      };
     };
    }; 
   };
  };
 }
 catch(...)
 {
   ShowMessage("Can't open file "+FileInf[PresentNamberFile].Name);
 };
 Quit:
 delete Jpeg1;
 delete Bitmap1;
};
//------------------------------------------------------------------------------
void __fastcall TSearchJpegFile::ShowProcess(void)
{
((TMain_Form*)Application->MainForm)->ShowProcess();
};
//------------------------------------------------------------------------------
void __fastcall TSearchJpegFile::CheckOnDefect(void)
{
int iFileHandle;
char *Char=new char [2];
iFileHandle=FileOpen(FileInf[PresentNamberFile].Name,fmOpenRead);
if(iFileHandle>=0)
{
 FileSeek(iFileHandle,-2,2);
 FileRead(iFileHandle,Char,2);
}
else
{
 Char[0]=' ';
 Char[1]=' ';
};
FileClose(iFileHandle);
if((Char[0]!='�')||(Char[1]!='�'))
{
 if(Log->AutoDeleteDefect)
 {
  FileDelete(FileInf[PresentNamberFile].Name,Log->DeleteToRecycleBin);
  FileInf[PresentNamberFile].Exist=false;
 }
 else
 {
  switch (Delete_Dialog->Show(Log, FileInf[PresentNamberFile].Name))
  {
   case 1: Stop();break;
   case 2:
   {
    FileDelete(FileInf[PresentNamberFile].Name,Log->DeleteToRecycleBin);
    FileInf[PresentNamberFile].Exist=false;
   };break;
   default :;
  };
 };
};
};
//------------------------------------------------------------------------------

