/*
AntiDupl-1.17
Yermalayeu Ihar 
Minsk, Belarus 
2002-2005
http://antidupl.narod.ru
*/
//---------------------------------------------------------------------------
#include "Option_Unit.h"
#include <inifiles.hpp>
#include "Common_Units\File_Unit.h"
#include <vcl.h>
//----------------------------------------------------------------------------
__fastcall TSearchLog::TSearchLog(void)
{
if (FileExists(GetWinDir()+"\\AntiDupl.ini"))
{
 TIniFile *Ini=new TIniFile(GetWinDir()+"\\AntiDupl.ini");
 AutoDeleteDefect=Ini->ReadBool("Option","AutoDeleteDefect",false);
 AutoDeleteEqual=Ini->ReadBool("Option","AutoDeleteEqual",false);
 DeleteToRecycleBin=Ini->ReadBool("Option","DeleteToRecycleBin",true);
 CheckOnDefect=Ini->ReadBool("Option","CheckOnDefect",true);
 CheckOnEquality=Ini->ReadBool("Option","CheckOnEquality",true);
 FullPicture=Ini->ReadBool("Option","FullPicture",true);
 SizeControl=Ini->ReadBool("Option","SizeControl",true);
 CompareOder=Ini->ReadInteger("Option","CompareOder",16);
 DirectoryName=Ini->ReadString("Option","DirectoryName",GetCurrentDir());
 SubDirectories=Ini->ReadBool("Option","SubDirectories",true);
 Language=Ini->ReadString("Option","Language","English");
 DeleteDialogHeight = Ini->ReadInteger("Size","DeleteDialogHeight", 369);
 if(DeleteDialogHeight < 369) DeleteDialogHeight = 369;
 DeleteDialogWidth = Ini->ReadInteger("Size","DeleteDialogWidth", 296);
 if(DeleteDialogWidth < 296) DeleteDialogWidth = 296;
 CompareDialogHeight = Ini->ReadInteger("Size","CompareDialogHeight", 371);
 if(CompareDialogHeight < 371) CompareDialogHeight = 371;
 CompareDialogWidth = Ini->ReadInteger("Size","CompareDialogWidth", 584);
 if(CompareDialogWidth < 584) CompareDialogWidth = 584;
 delete Ini;
}
else
{
 AutoDeleteDefect=false;
 AutoDeleteEqual=false;
 CheckOnDefect=true;
 CheckOnEquality=true;
 CompareOder=16;
 DeleteToRecycleBin=true;
 SizeControl=false;
 FullPicture=false;
 SubDirectories=true;
 DirectoryName=GetCurrentDir();
 Language="English";
 DeleteDialogHeight = 369;
 DeleteDialogWidth = 296;
 CompareDialogHeight = 371;
 CompareDialogWidth = 584;
};
};
//---------------------------------------------------------------------------
void __fastcall TSearchLog::Assign(TSearchLog *temp)
{
 AutoDeleteDefect=temp->AutoDeleteDefect;
 AutoDeleteEqual=temp->AutoDeleteEqual;
 CheckOnDefect=temp->CheckOnDefect;
 CheckOnEquality=temp->CheckOnEquality;
 CompareOder=temp->CompareOder;
 DeleteToRecycleBin=temp->DeleteToRecycleBin;
 SizeControl=temp->SizeControl;
 FullPicture=temp->FullPicture;
 DirectoryName=temp->DirectoryName;
 SubDirectories=temp->SubDirectories;
 Language=temp->Language;
 DeleteDialogHeight = temp->DeleteDialogHeight;
 DeleteDialogWidth = temp->DeleteDialogWidth;
 CompareDialogHeight = temp->CompareDialogHeight;
 CompareDialogWidth = temp->CompareDialogWidth;
};
//---------------------------------------------------------------------------
__fastcall TSearchLog::~TSearchLog(void)
{
 if(!FileExists(GetWinDir()+"\\AntiDupl.ini"))
    FileClose(FileCreate(GetWinDir()+"\\AntiDupl.ini"));
 TIniFile *Ini=new TIniFile(GetWinDir()+"\\AntiDupl.ini");
 Ini->WriteBool("Option","AutoDeleteDefect",AutoDeleteDefect);
 Ini->WriteBool("Option","AutoDeleteEqual",AutoDeleteEqual);
 Ini->WriteBool("Option","DeleteToRecycleBin",DeleteToRecycleBin);
 Ini->WriteBool("Option","CheckOnDefect",CheckOnDefect);
 Ini->WriteBool("Option","CheckOnEquality",CheckOnEquality);
 Ini->WriteBool("Option","FullPicture",FullPicture);
 Ini->WriteBool("Option","SizeControl",SizeControl);
 Ini->WriteInteger("Option","CompareOder",CompareOder);
 Ini->WriteString("Option","DirectoryName",DirectoryName);
 Ini->WriteBool("Option","SubDirectories",SubDirectories);
 Ini->WriteString("Option","Language",Language);
 Ini->WriteInteger("Size","DeleteDialogHeight", DeleteDialogHeight);
 Ini->WriteInteger("Size","DeleteDialogWidth", DeleteDialogWidth);
 Ini->WriteInteger("Size","CompareDialogHeight", CompareDialogHeight);
 Ini->WriteInteger("Size","CompareDialogWidth", CompareDialogWidth);
 Ini->UpdateFile();
 delete Ini;
};
//---------------------------------------------------------------------------
TCaptions::TCaptions(void)
{
Str=new AnsiString[50];
};
//------------------------------------------------------------------------------
TCaptions::~TCaptions(void)
{
delete[] Str;
};
//------------------------------------------------------------------------------
bool TCaptions::Load(AnsiString Section)
{
bool res=false;
int i;
char str[255];
if (FileExists(ChangeFileExt(Application->ExeName,".dat")))
{
 TIniFile *Ini=new TIniFile(ChangeFileExt(Application->ExeName,".dat"));
 for(i=0;i<50;i++)
 {
  Str[i]=Ini->ReadString(Section,"Str["+IntToStr(i)+"]","");
 };
 delete Ini;
 res=true;
};
return res;
};
//------------------------------------------------------------------------------
AnsiString TCaptions::Get(int i)
{
AnsiString str="";
try
{
 str=Str[i];
}
catch(...)
{

};
return str;
};
//------------------------------------------------------------------------------

