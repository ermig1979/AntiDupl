/*
AntiDupl-1.17
Yermalayeu Ihar 
Minsk, Belarus 
2002-2005
http://antidupl.narod.ru
*/
//---------------------------------------------------------------------------

#ifndef Compare_Dialog_UnitH
#define Compare_Dialog_UnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
const int CmpDld_FromBottom_Button = 78;//105;
const int CmpDld_FromCenter_Stop = -210;
const int CmpDld_FromCenter_Delete_Left = -111;
const int CmpDld_FromCenter_Delete_Right = 11;
const int CmpDld_FromCenter_Next = 121;
const int CmpDld_FromBottom_Image = 86;//113;
const int CmpDld_FromCenter_Image = 36;
const int CmpDld_FromCenter_Right_Image = 12;
//---------------------------------------------------------------------------
class TSearchLog;
//---------------------------------------------------------------------------
class TCompare_Dialog : public TForm
{
__published:	// IDE-managed Components
        TImage *Left_Image;
        TImage *Right_Image;
        TButton *Delete_Left_Button;
        TButton *Delete_Right_Button;
        TButton *Next_Button;
        TButton *Stop_Button;
        TStatusBar *StatusBar2;
        TStatusBar *StatusBar1;
        void __fastcall Next_ButtonClick(TObject *Sender);
        void __fastcall Delete_Left_ButtonClick(TObject *Sender);
        void __fastcall Delete_Right_ButtonClick(TObject *Sender);
        void __fastcall Stop_ButtonClick(TObject *Sender);
        void __fastcall FormResize(TObject *Sender);
private:	// User declarations
        int Answer;
        Graphics::TBitmap *pLeftBitmap;
        Graphics::TBitmap *pRightBitmap;
public:		// User declarations
       int __fastcall Show(TSearchLog *pLog, AnsiString LeftFileName, AnsiString RightFileName);
        __fastcall TCompare_Dialog(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TCompare_Dialog *Compare_Dialog;
//---------------------------------------------------------------------------
#endif
