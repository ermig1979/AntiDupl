/*
AntiDupl-1.17
Yermalayeu Ihar 
Minsk, Belarus 
2002-2005
http://antidupl.narod.ru
*/
//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "Delete_Dialog_Unit.h"
#include <jpeg.hpp>
#include "Common_Units\Graph_Unit.h"
#include "Main_Form_Unit.h"
#include "Option_Unit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TDelete_Dialog *Delete_Dialog;
//---------------------------------------------------------------------------
__fastcall TDelete_Dialog::TDelete_Dialog(TComponent* Owner)
        : TForm(Owner)
{
Answer=0;
}
//---------------------------------------------------------------------------
void __fastcall TDelete_Dialog::Delete_ButtonClick(TObject *Sender)
{
Answer=2;
Close();        
}
//---------------------------------------------------------------------------

void __fastcall TDelete_Dialog::Next_ButtonClick(TObject *Sender)
{
Answer=0;
Close();
}
//---------------------------------------------------------------------------


void __fastcall TDelete_Dialog::Stop_ButtonClick(TObject *Sender)
{
Answer=1;
Close();
}
//---------------------------------------------------------------------------
int __fastcall TDelete_Dialog::Show(TSearchLog *pLog, AnsiString FileName)
{
Application->Icon->Handle=LoadIcon(HInstance,"RED");
Main_Form->Icon->Handle=LoadIcon(HInstance,"RED");
Answer=0;
Stop_Button->Caption=Str->Get(3);
Delete_Button->Caption=Str->Get(28);
Next_Button->Caption=Str->Get(29);
Caption=Str->Get(30);
pBitmap = new Graphics::TBitmap();
TJPEGImage *pJpeg = new TJPEGImage();
StatusBar1->Panels->Items[2]->Text=ExtractFileName(FileName);
AnsiString temp=ExtractFilePath(FileName);
temp.Delete(1, pLog->DirectoryName.Length());
StatusBar2->SimpleText="..."+temp;
try
{
 pJpeg->LoadFromFile(FileName);
 pJpeg->Grayscale=false;
 StatusBar1->Panels->Items[1]->Text=IntToStr(pJpeg->Width)+"x"+IntToStr(pJpeg->Height);
 pBitmap->Assign(pJpeg);
 int iFileHandle=FileOpen(FileName, fmOpenRead);
 int l=FileSeek(iFileHandle,0,2);
 if(l%1000>=100)StatusBar1->Panels->Items[0]->Text=IntToStr(l/1000)+" "+IntToStr(l%1000)+" B";
 if((l%1000<100)&&(l%1000>=10))StatusBar1->Panels->Items[0]->Text=IntToStr(l/1000)+" 0"+IntToStr(l%1000)+" B";
 if(l%1000<10)StatusBar1->Panels->Items[0]->Text=IntToStr(l/1000)+" 00"+IntToStr(l%1000)+" B";
 FileClose(iFileHandle);
 StretchBitmapToImage(Image,pBitmap);
}
catch(...)
{
 ShowMessage("Can't open file "+FileName);
};
 Height = pLog->DeleteDialogHeight;
 Width = pLog->DeleteDialogWidth;
 ShowModal();
 pLog->DeleteDialogHeight = Height;
 pLog->DeleteDialogWidth = Width;
delete pJpeg;
delete pBitmap;
Application->Icon->Handle=LoadIcon(HInstance,"YELLOW");
Main_Form->Icon->Handle=LoadIcon(HInstance,"YELLOW");
return Answer;
};
//---------------------------------------------------------------------------

void __fastcall TDelete_Dialog::FormResize(TObject *Sender)
{
 Stop_Button->Top = ClientHeight - DelDld_FromBottom_Button;
 Delete_Button->Top = ClientHeight - DelDld_FromBottom_Button;
 Next_Button->Top = ClientHeight - DelDld_FromBottom_Button;

 Stop_Button->Left = Width/2 + DelDld_FromCenter_Stop;
 Delete_Button->Left = Width/2 + DelDld_FromCenter_Delete;
 Next_Button->Left = Width/2 + DelDld_FromCenter_Next;

 Image->Height = ClientHeight - DelDld_FromBottom_Image;
 Image->Width = Width - DelDld_FromRight_Image;
 Image->Picture->Bitmap->Height = ClientHeight - DelDld_FromBottom_Image;
 Image->Picture->Bitmap->Width = Width - DelDld_FromRight_Image;
 
 StretchBitmapToImage(Image, pBitmap);
}
//---------------------------------------------------------------------------



