/*
AntiDupl-1.17
Yermalayeu Ihar 
Minsk, Belarus 
2002-2005
http://antidupl.narod.ru
*/
//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#include <Classes.hpp>
#include <ComCtrls.hpp>
#include <Controls.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include <StdCtrls.hpp>
#include <Menus.hpp>
#include <ToolWin.hpp>
#include <ImgList.hpp>
#pragma hdrstop

#ifndef Main_Form_UnitH
#define Main_Form_UnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
#include <Graphics.hpp>
#include "Option_Unit.h"
//---------------------------------------------------------------------------
class TMain_Form : public TForm
{
__published:	// IDE-managed Components
        TStatusBar *Progress_Status_Bar;
        TMainMenu *MainMenu1;
        TMenuItem *Browse;
        TMenuItem *Option;
        TMenuItem *DeleteToRecycleBin;
        TMenuItem *CheckOnDefect;
        TMenuItem *AutoDeleteDefect;
        TMenuItem *Exit;
        TMenuItem *Start_Stop;
        TMenuItem *CheckOnEquality;
        TMenuItem *RateOfDifference;
        TMenuItem *FullPicture;
        TMenuItem *SizeControl;
        TMenuItem *DNone;
        TMenuItem *DSmall;
        TMenuItem *DMiddle;
        TMenuItem *DBig;
        TMenuItem *DVeryBig;
        TStatusBar *FileNameStatusBar;
        TMenuItem *SubDirectories;
        TMenuItem *Help;
        TMenuItem *Language;
        TMenuItem *English;
        TMenuItem *Russian;
        TMenuItem *About;
         TMenuItem *DefaultOption;
        TMenuItem *AutoDeleteEqual;
        void __fastcall FormKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall DeleteToRecycleBinClick(TObject *Sender);
        void __fastcall CheckOnDefectClick(TObject *Sender);
        void __fastcall ExitClick(TObject *Sender);
        void __fastcall BrowseClick(TObject *Sender);
        void __fastcall Start_StopClick(TObject *Sender);
        void __fastcall AutoDeleteDefectClick(TObject *Sender);
        void __fastcall CheckOnEqualityClick(TObject *Sender);
        void __fastcall FullPictureClick(TObject *Sender);
        void __fastcall SizeControlClick(TObject *Sender);
        void __fastcall DNoneClick(TObject *Sender);
        void __fastcall DSmallClick(TObject *Sender);
        void __fastcall DMiddleClick(TObject *Sender);
        void __fastcall DBigClick(TObject *Sender);
        void __fastcall DVeryBigClick(TObject *Sender);
        void __fastcall SubDirectoriesClick(TObject *Sender);
        void __fastcall EnglishClick(TObject *Sender);
        void __fastcall RussianClick(TObject *Sender);
        void __fastcall AboutClick(TObject *Sender);
        void __fastcall DefaultOptionClick(TObject *Sender);
        void __fastcall AutoDeleteEqualClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TMain_Form(TComponent* Owner);
        __fastcall ~TMain_Form(void);
        void __fastcall ShowProcess(void);
        void __fastcall Refresh(void);
};
//---------------------------------------------------------------------------
extern PACKAGE TMain_Form *Main_Form;
extern PACKAGE TCaptions *Str;
//---------------------------------------------------------------------------
#endif

