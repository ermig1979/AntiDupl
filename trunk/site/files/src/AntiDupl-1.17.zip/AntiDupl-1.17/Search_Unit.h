/*
AntiDupl-1.17
Yermalayeu Ihar 
Minsk, Belarus 
2002-2005
http://antidupl.narod.ru
*/
#include <SysUtils.hpp>
#include "Main_Form_Unit.h"
#define NPix 32
//------------------------------------------------------------------------------
class TFileInf
{
public:
 bool Exist;
 AnsiString Name;
 int Size;
 int Height;
 int Width;
 unsigned char ComparePixels[NPix][NPix];
};
//------------------------------------------------------------------------------
class TSearchJpegFile
{
private:
        bool BoolRun;
        TFileInf *FileInf;
        int TotalAmountFile;
        int PresentNamberFile;
        void __fastcall SearchNamberFile(AnsiString DirectoryName);
        void __fastcall SearchFileInf(AnsiString DirectoryName);
        void __fastcall CheckOnDefect(void);
        void __fastcall CheckOnEquality(void);
        void __fastcall ShowProcess(void);
public:
        TSearchLog *Log;
        __fastcall TSearchJpegFile(void);
        __fastcall ~TSearchJpegFile(void);
        void __fastcall Search(void);
        AnsiString GetPresentFileName(void);
        int GetTotalAmountFile(void);
        int GetPresentNamberFile(void);
        bool IfRun(void){return BoolRun;};
        void Stop(void){BoolRun=false;};
};
//------------------------------------------------------------------------------
