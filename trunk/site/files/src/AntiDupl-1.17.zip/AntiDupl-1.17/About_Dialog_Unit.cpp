/*
AntiDupl-1.17
Yermalayeu Ihar 
Minsk, Belarus 
2002-2005
http://antidupl.narod.ru
*/
//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "About_Dialog_Unit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TAbout_Dialog *About_Dialog;
//---------------------------------------------------------------------------
__fastcall TAbout_Dialog::TAbout_Dialog(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TAbout_Dialog::OKClick(TObject *Sender)
{
 Close();        
}
//---------------------------------------------------------------------------
void __fastcall TAbout_Dialog::Show(const AnsiString &Language)
{
 Athor->Caption = "Yermolayev Ihar.";
 Place->Caption = "Minsk, Belarus.";
 if(Language == "English")
 {
  Athor->Caption = "Yermolayev Ihar.";
  Place->Caption = "Minsk, Belarus.";
 };
 if(Language == "Russian")
 {
  Athor->Caption = "�������� �����.";
  Place->Caption = "�����, ��������.";
 };
 ShowModal();
};
//---------------------------------------------------------------------------

void __fastcall TAbout_Dialog::FormMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
 if(X >= Name->Left &&  X <= Name->Left + Name->Width &&
    Y >= Name->Top && Y <= Name->Top + Name->Height)
 {
  Cursor = crHandPoint;
  Name->Font->Color = clBlue;
 }
 else
 {
  Cursor = crArrow;
  Name->Font->Color = clBlack;
 };
}
//---------------------------------------------------------------------------
void __fastcall TAbout_Dialog::NameClick(TObject *Sender)
{
 ShellExecute(Handle, "open", "http://antidupl.narod.ru", NULL, NULL, SW_SHOWNORMAL);
}
//---------------------------------------------------------------------------

