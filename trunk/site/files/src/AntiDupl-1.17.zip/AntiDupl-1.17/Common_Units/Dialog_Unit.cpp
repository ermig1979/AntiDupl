/*
AntiDupl-1.17
Yermalayeu Ihar 
Minsk, Belarus 
2002-2005
http://antidupl.narod.ru
*/
#define NO_WIN32_LEAN_AND_MEAN
#include <shlobj.h>
#include "Dialog_Unit.h"
#include "File_Unit.h"
#include <Filectrl.hpp>
//-------------------- Select Folder -------------------------------------------
static int CALLBACK BrowseCallbackProc(HWND hWnd, UINT uMsg, LPARAM lParam, LPARAM lpData)
{
switch (uMsg)
{
 case BFFM_INITIALIZED:
  if (lpData) SendMessage(hWnd,BFFM_SETSELECTION,WPARAM(true),lpData);
 break;
 case BFFM_SELCHANGED:
  LPITEMIDLIST(lParam);
 break;
}
return 0;
}
//------------------------------------------------------------------------------
bool SelectFolder(AnsiString Caption,AnsiString &Path,HWND hWndOwner=NULL)
{
char Temp_Path[MAX_PATH];
BROWSEINFO MyBrInfo;
ZeroMemory(&MyBrInfo,sizeof(MyBrInfo));
MyBrInfo.hwndOwner = hWndOwner;
MyBrInfo.pidlRoot = NULL;
MyBrInfo.pszDisplayName = NULL;
MyBrInfo.lpszTitle =Caption.c_str();
MyBrInfo.ulFlags = BIF_RETURNONLYFSDIRS;
MyBrInfo.lpfn = BrowseCallbackProc;
MyBrInfo.lParam = LPARAM(Path.c_str());
MyBrInfo.iImage = NULL;
SHGetPathFromIDList(SHBrowseForFolder(&MyBrInfo),Temp_Path);
if(DirExists(Temp_Path))
{
 Path=Temp_Path;
};
return true;
};
//------------------------------------------------------------------------------
