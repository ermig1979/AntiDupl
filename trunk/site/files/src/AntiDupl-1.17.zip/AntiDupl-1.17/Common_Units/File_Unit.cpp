/*
AntiDupl-1.17
Yermalayeu Ihar 
Minsk, Belarus 
2002-2005
http://antidupl.narod.ru
*/
#include "File_Unit.h"
#include <shellapi.h>
#include <windows.h>
#include <tchar.h>
//------------------------------------------------------------------------------
int FileDelete(AnsiString FileName,bool Recycle)
{
TCHAR buf[_MAX_PATH + 1];
_tcscpy(buf, FileName.c_str());
buf[_tcslen(buf)+1]=0;
SHFILEOPSTRUCT del_var;
ZeroMemory(&del_var,sizeof(del_var));
del_var.wFunc=FO_DELETE;
del_var.pTo = NULL;
del_var.pFrom=buf;
del_var.fFlags=FOF_SILENT|FOF_NOCONFIRMATION|FOF_NOERRORUI;
if (Recycle) del_var.fFlags|=FOF_ALLOWUNDO;
else del_var.fFlags &= ~FOF_ALLOWUNDO;
return SHFileOperation(&del_var);
};
//------------------------------------------------------------------------------
bool DirExists(AnsiString DirName)
{
int Code;
Code=GetFileAttributes(DirName.c_str());
return ((Code!=-1)&&FILE_ATTRIBUTE_DIRECTORY&&(Code!=0));
};
//------------------------------------------------------------------------------
AnsiString GetWinDir(void)
{
char WinDir[MAX_PATH];
GetWindowsDirectory(WinDir,MAX_PATH);
return WinDir;
};
//------------------------------------------------------------------------------

