/*
AntiDupl-1.17
Yermalayeu Ihar 
Minsk, Belarus 
2002-2005
http://antidupl.narod.ru
*/
#include "Graph_Unit.h"
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
void __fastcall StretchBitmapToImage(TImage *Image,Graphics::TBitmap *Bitmap)
{
  TRect Rect;
  TColor TempBrushColor,TempPenColor;
  TempBrushColor=Image->Canvas->Brush->Color;
  TempPenColor=Image->Canvas->Pen->Color;
  Image->Canvas->Brush->Color=clDkGray;
  Image->Canvas->Pen->Color=clDkGray;
  Image->Canvas->Rectangle(0, 0, Image->Width, Image->Height);
  Image->Canvas->Brush->Color=TempBrushColor;
  Image->Canvas->Pen->Color=TempPenColor;
  if(float(Bitmap->Width)/float(Bitmap->Height) >
     float(Image->Width)/float(Image->Height))
  {
   Rect.Left = 0;
   Rect.Right = Image->Width;
   Rect.Top = (Image->Height - (Image->Width*Bitmap->Height)/Bitmap->Width)/2;
   Rect.Bottom = (Image->Height + (Image->Width*Bitmap->Height)/Bitmap->Width)/2;
  }
  else
  {
   Rect.Top = 0;
   Rect.Bottom = Image->Height;
   Rect.Left = (Image->Width - (Image->Height*Bitmap->Width)/Bitmap->Height)/2;
   Rect.Right = (Image->Width + (Image->Height*Bitmap->Width)/Bitmap->Height)/2;
  };
  Image->Canvas->StretchDraw(Rect, Bitmap);
};
//------------------------------------------------------------------------------
void __fastcall BitmapToCanvasRect(Graphics::TBitmap *Bitmap1,
                                         TCanvas *Canvas1,TRect Rect1)
{
  TColor TempBrushColor,TempPenColor;
  TempBrushColor=Canvas1->Brush->Color;
  TempPenColor=Canvas1->Pen->Color;
  Canvas1->Brush->Color=clDkGray;
  Canvas1->Pen->Color=clDkGray;
  int Height=Rect1.Bottom-Rect1.Top,Width=Rect1.Right-Rect1.Left;
  Canvas1->Rectangle(Rect1);
  Canvas1->Brush->Color=TempBrushColor;
  Canvas1->Pen->Color=TempPenColor;

  if(double(Bitmap1->Height)/Bitmap1->Width>double(Height)/Width)
  {
   Rect1.Right=Rect1.Left+Width/2+(Width*Bitmap1->Width)/Bitmap1->Height/2;
   Rect1.Left=Rect1.Left+Width/2-(Width*Bitmap1->Width)/Bitmap1->Height/2;
  }
  else
  {
   Rect1.Bottom=Rect1.Top+Height/2+(Height*Bitmap1->Height)/Bitmap1->Width/2;
   Rect1.Top=Rect1.Top+Height/2-(Height*Bitmap1->Height)/Bitmap1->Width/2;
  };
  Canvas1->StretchDraw(Rect1, Bitmap1);
};
//------------------------------------------------------------------------------
void __fastcall BitmapToCanvasRect(Graphics::TBitmap *Bitmap1,TCanvas *Canvas1,
                                                 int X1, int Y1, int X2, int Y2)
{
  TRect Rect1;
  TColor TempBrushColor,TempPenColor;
  TempBrushColor=Canvas1->Brush->Color;
  TempPenColor=Canvas1->Pen->Color;
  Canvas1->Brush->Color=clDkGray;
  Canvas1->Pen->Color=clDkGray;
  Canvas1->Rectangle(X1,Y1,X2,Y2);
  Canvas1->Brush->Color=TempBrushColor;
  Canvas1->Pen->Color=TempPenColor;

  if(double(Bitmap1->Height)/Bitmap1->Width>double(Y2-Y1)/(X2-X1))
  {
   Rect1.Top=Y1;
   Rect1.Left=(X2+X1)/2-((X2-X1)*Bitmap1->Width)/Bitmap1->Height/2;
   Rect1.Bottom=Y2;
   Rect1.Right=(X2+X1)/2+((X2-X1)*Bitmap1->Width)/Bitmap1->Height/2;
  }
  else
  {
   Rect1.Top=(Y2+Y1)/2-((Y2-Y1)*Bitmap1->Height)/Bitmap1->Width/2;
   Rect1.Left=X1;
   Rect1.Bottom=(Y2+Y1)/2+((Y2-Y1)*Bitmap1->Height)/Bitmap1->Width/2;
   Rect1.Right=X2;
  };
  Canvas1->StretchDraw(Rect1,Bitmap1);
};
//------------------------------------------------------------------------------
