/*
AntiDupl-1.17
Yermalayeu Ihar 
Minsk, Belarus 
2002-2005
http://antidupl.narod.ru
*/
#include <vcl.h>
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
void __fastcall StretchBitmapToImage(TImage *Image1,Graphics::TBitmap *Bitmap1);
//------------------------------------------------------------------------------
void __fastcall BitmapToCanvasRect(Graphics::TBitmap *Bitmap1,
                                        TCanvas *Canvas1,TRect Rect1);
//------------------------------------------------------------------------------
void __fastcall BitmapToCanvasRect(Graphics::TBitmap *Bitmap1,TCanvas *Canvas1,
                                                int X1, int Y1, int X2, int Y2);
//------------------------------------------------------------------------------

 