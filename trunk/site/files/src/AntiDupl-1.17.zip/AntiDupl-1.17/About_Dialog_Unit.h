/*
AntiDupl-1.17
Yermalayeu Ihar 
Minsk, Belarus 
2002-2005
http://antidupl.narod.ru
*/
//---------------------------------------------------------------------------

#ifndef About_Dialog_UnitH
#define About_Dialog_UnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
//---------------------------------------------------------------------------
class TAbout_Dialog : public TForm
{
__published:	// IDE-managed Components
        TButton *OK;
        TImage *Flag;
        TLabel *Place;
        TLabel *Athor;
        TLabel *Name;
        TLabel *Date;
        TImage *Icon;
        void __fastcall OKClick(TObject *Sender);
        void __fastcall FormMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
        void __fastcall NameClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        void __fastcall Show(const AnsiString &Language);
        __fastcall TAbout_Dialog(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TAbout_Dialog *About_Dialog;
//---------------------------------------------------------------------------
#endif
