/*
AntiDupl-1.17
Yermalayeu Ihar 
Minsk, Belarus 
2002-2005
http://antidupl.narod.ru
*/
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "Main_Form_Unit.h"
#include "About_Dialog_Unit.h"
#include "Search_Unit.h"
#include "Common_Units\Dialog_Unit.h"
#include "Common_Units\File_Unit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMain_Form *Main_Form;
TSearchJpegFile *SJF;
TCaptions *Str;
//---------------------------------------------------------------------------
__fastcall TMain_Form::TMain_Form(TComponent* Owner)
        : TForm(Owner)
{
SJF=new TSearchJpegFile();
Str=new TCaptions();
}
//---------------------------------------------------------------------------
__fastcall TMain_Form::~TMain_Form(void)
{
delete SJF;
delete Str;
}
//---------------------------------------------------------------------------
void __fastcall TMain_Form::FormKeyUp(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
if(Key==VK_PAUSE)SJF->Stop();
}
//---------------------------------------------------------------------------
void __fastcall TMain_Form::ShowProcess(void)
{
Progress_Status_Bar->Panels->Items[0]->Text=SJF->GetTotalAmountFile();
Progress_Status_Bar->Panels->Items[1]->Text=SJF->GetPresentNamberFile();
FileNameStatusBar->SimpleText=SJF->GetPresentFileName();
if(SJF->GetPresentNamberFile()>0)
{
 TRect Rect;
 Progress_Status_Bar->Canvas->Brush->Color=clNavy;
 Progress_Status_Bar->Canvas->Pen->Color=clSilver;
 Rect.top=Progress_Status_Bar->BorderWidth+4;
 Rect.left=Progress_Status_Bar->Panels->Items[0]->Width+
           Progress_Status_Bar->Panels->Items[1]->Width+
           Progress_Status_Bar->BorderWidth+4;
 Rect.bottom=Progress_Status_Bar->Height-
             Progress_Status_Bar->BorderWidth-3;
 Rect.right=Progress_Status_Bar->Width-
            Progress_Status_Bar->BorderWidth-3;
 Rect.right=Rect.left+(SJF->GetPresentNamberFile()*(Rect.right-Rect.left))/
            SJF->GetTotalAmountFile();
 Progress_Status_Bar->Canvas->Rectangle(Rect);
 int procent=SJF->GetPresentNamberFile()*100/SJF->GetTotalAmountFile();
 Application->Title=IntToStr(procent)+Str->Get(1)+SJF->Log->DirectoryName;
 Main_Form->Caption=IntToStr(procent)+Str->Get(1)+SJF->Log->DirectoryName;
};
Application->ProcessMessages();
}
//---------------------------------------------------------------------------
void __fastcall TMain_Form::FormActivate(TObject *Sender)
{
 if(SJF->Log->Language=="English")
 {
  English->Checked=false;
  EnglishClick(Sender);
 };
 if(SJF->Log->Language=="Russian")
 {
  Russian->Checked=false;
  RussianClick(Sender);
 };
 if(!DirExists(SJF->Log->DirectoryName))SJF->Log->DirectoryName=GetCurrentDir();
 Refresh();
 DeleteToRecycleBin->Checked=SJF->Log->DeleteToRecycleBin;
 CheckOnDefect->Checked=SJF->Log->CheckOnDefect;
 AutoDeleteDefect->Checked=SJF->Log->AutoDeleteDefect;
 AutoDeleteEqual->Checked=SJF->Log->AutoDeleteEqual;
 CheckOnEquality->Checked=SJF->Log->CheckOnEquality;
 FullPicture->Checked=SJF->Log->FullPicture;
 SizeControl->Checked=SJF->Log->SizeControl;
 SubDirectories->Checked=SJF->Log->SubDirectories;
 switch ( SJF->Log->CompareOder)
 {
  case 0 : DNoneClick(Sender); break;
  case 8 : DSmallClick(Sender); break;
  case 16 : DMiddleClick(Sender); break;
  case 24 : DBigClick(Sender); break;
  case 32 : DVeryBigClick(Sender); break;
  default : DMiddleClick(Sender);
 };
 if(!CheckOnEquality->Checked)
 {
 FullPicture->Enabled=false;
 SizeControl->Enabled=false;
 RateOfDifference->Enabled=false;
 AutoDeleteEqual->Enabled=false;
 };
 if(!CheckOnDefect->Checked)
 {
 AutoDeleteDefect->Enabled=false;
 };
}
//---------------------------------------------------------------------------
void __fastcall TMain_Form::DeleteToRecycleBinClick(TObject *Sender)
{
if(DeleteToRecycleBin->Checked)
{
 DeleteToRecycleBin->Checked=false;
 SJF->Log->DeleteToRecycleBin=DeleteToRecycleBin->Checked;
}
else
{
 DeleteToRecycleBin->Checked=true;
 SJF->Log->DeleteToRecycleBin=DeleteToRecycleBin->Checked;
};
}
//---------------------------------------------------------------------------
void __fastcall TMain_Form::CheckOnDefectClick(TObject *Sender)
{
if(CheckOnDefect->Checked)
{
 CheckOnDefect->Checked=false;
 SJF->Log->CheckOnDefect=CheckOnDefect->Checked;
 AutoDeleteDefect->Enabled=false;
}
else
{
 CheckOnDefect->Checked=true;
 SJF->Log->CheckOnDefect=CheckOnDefect->Checked;
 AutoDeleteDefect->Enabled=true;
};
}
//---------------------------------------------------------------------------
void __fastcall TMain_Form::ExitClick(TObject *Sender)
{
Close();
}
//---------------------------------------------------------------------------
void __fastcall TMain_Form::BrowseClick(TObject *Sender)
{
AnsiString Path=SJF->Log->DirectoryName;
SelectFolder(Str->Get(2),Path,this->Handle);
Main_Form->Caption=Str->Get(0)+Path;
Application->Title=Str->Get(0)+Path;
SJF->Log->DirectoryName=Path;
}
//---------------------------------------------------------------------------
void __fastcall TMain_Form::Start_StopClick(TObject *Sender)
{
if (SJF->IfRun())
{
 SJF->Stop();
}
else
{
 Application->Icon->Handle=LoadIcon(HInstance,"YELLOW");
 Main_Form->Icon->Handle=LoadIcon(HInstance,"YELLOW");
 Start_Stop->Caption=Str->Get(3);
 Exit->Visible=false;
 Browse->Visible=false;
 Option->Visible=false;
 Help->Visible=false;
 SJF->Search();
 Application->Icon->Handle=LoadIcon(HInstance,"GREEN");
 Main_Form->Icon->Handle=LoadIcon(HInstance,"GREEN");
 Exit->Visible=true;
 Browse->Visible=true;
 Option->Visible=true;
 Help->Visible=true;
 Refresh();
 TRect Rect;
 Progress_Status_Bar->Canvas->Brush->Color=clSilver;
 Progress_Status_Bar->Canvas->Pen->Color=clSilver;
 Rect.top=Progress_Status_Bar->BorderWidth+4;
 Rect.left=Progress_Status_Bar->Panels->Items[0]->Width+
           Progress_Status_Bar->Panels->Items[1]->Width+
           Progress_Status_Bar->BorderWidth+4;
 Rect.bottom=Progress_Status_Bar->Height-
             Progress_Status_Bar->BorderWidth-4;
 Rect.right=Progress_Status_Bar->Width-
            Progress_Status_Bar->BorderWidth-4;
 Progress_Status_Bar->Canvas->Rectangle(Rect);
};
}
//---------------------------------------------------------------------------
void __fastcall TMain_Form::AutoDeleteDefectClick(TObject *Sender)
{
if(AutoDeleteDefect->Checked)
{
 AutoDeleteDefect->Checked=false;
 SJF->Log->AutoDeleteDefect=AutoDeleteDefect->Checked;
}
else
{
 AutoDeleteDefect->Checked=true;
 SJF->Log->AutoDeleteDefect=AutoDeleteDefect->Checked;
};
}
//---------------------------------------------------------------------------
void __fastcall TMain_Form::CheckOnEqualityClick(TObject *Sender)
{
if(CheckOnEquality->Checked)
{
 CheckOnEquality->Checked=false;
 SJF->Log->CheckOnEquality=CheckOnEquality->Checked;
 FullPicture->Enabled=false;
 SizeControl->Enabled=false;
 RateOfDifference->Enabled=false;
 AutoDeleteEqual->Enabled=false;
}
else
{
 CheckOnEquality->Checked=true;
 SJF->Log->CheckOnEquality=CheckOnEquality->Checked;
 FullPicture->Enabled=true;
 SizeControl->Enabled=true;
 RateOfDifference->Enabled=true;
 AutoDeleteEqual->Enabled=true;
};
}
//---------------------------------------------------------------------------
void __fastcall TMain_Form::FullPictureClick(TObject *Sender)
{
if(FullPicture->Checked)
{
 FullPicture->Checked=false;
 SJF->Log->FullPicture=FullPicture->Checked;
}
else
{
 FullPicture->Checked=true;
 SJF->Log->FullPicture=FullPicture->Checked;
};
}
//---------------------------------------------------------------------------
void __fastcall TMain_Form::SizeControlClick(TObject *Sender)
{
if(SizeControl->Checked)
{
 SizeControl->Checked=false;
 SJF->Log->SizeControl=SizeControl->Checked;
}
else
{
 SizeControl->Checked=true;
 SJF->Log->SizeControl=SizeControl->Checked;
};
}
//---------------------------------------------------------------------------

void __fastcall TMain_Form::DNoneClick(TObject *Sender)
{
if(!DNone->Checked)
{
 SJF->Log->CompareOder=0;
 DNone->Checked=true;
 DSmall->Checked=false;
 DMiddle->Checked=false;
 DBig->Checked=false;
 DVeryBig->Checked=false;
};
}
//---------------------------------------------------------------------------
void __fastcall TMain_Form::DSmallClick(TObject *Sender)
{
if(!DSmall->Checked)
{
 SJF->Log->CompareOder=8;
 DNone->Checked=false;
 DSmall->Checked=true;
 DMiddle->Checked=false;
 DBig->Checked=false;
 DVeryBig->Checked=false;
};
}
//---------------------------------------------------------------------------
void __fastcall TMain_Form::DMiddleClick(TObject *Sender)
{
if(!DMiddle->Checked)
{
 SJF->Log->CompareOder=16;
 DNone->Checked=false;
 DSmall->Checked=false;
 DMiddle->Checked=true;
 DBig->Checked=false;
 DVeryBig->Checked=false;
};
}
//---------------------------------------------------------------------------
void __fastcall TMain_Form::DBigClick(TObject *Sender)
{
if(!DBig->Checked)
{
 SJF->Log->CompareOder=24;
 DNone->Checked=false;
 DSmall->Checked=false;
 DMiddle->Checked=false;
 DBig->Checked=true;
 DVeryBig->Checked=false;
};
}
//---------------------------------------------------------------------------
void __fastcall TMain_Form::DVeryBigClick(TObject *Sender)
{
if(!DVeryBig->Checked)
{
 SJF->Log->CompareOder=32;
 DNone->Checked=false;
 DSmall->Checked=false;
 DMiddle->Checked=false;
 DBig->Checked=false;
 DVeryBig->Checked=true;
};
}
//---------------------------------------------------------------------------
void __fastcall TMain_Form::SubDirectoriesClick(TObject *Sender)
{
if(SubDirectories->Checked)
{
 SubDirectories->Checked=false;
 SJF->Log->SubDirectories=SubDirectories->Checked;
}
else
{
 SubDirectories->Checked=true;
 SJF->Log->SubDirectories=SubDirectories->Checked;
};
}
//---------------------------------------------------------------------------

void __fastcall TMain_Form::EnglishClick(TObject *Sender)
{
if(!English->Checked)
{
 English->Checked=true;
 Russian->Checked=false;
 SJF->Log->Language="English";
 if(!Str->Load(SJF->Log->Language))
 {
  ShowMessage("Can't find 'AntiDupl.dat' file");
  Close();
 };
 Refresh();
};
}
//---------------------------------------------------------------------------

void __fastcall TMain_Form::RussianClick(TObject *Sender)
{
if(!Russian->Checked)
{
 Russian->Checked=true;
 English->Checked=false;
 SJF->Log->Language="Russian";
 if(!Str->Load(SJF->Log->Language))
 {
  ShowMessage("Can't find 'AntiDupl.dat' file");
  Close();
 }; 
 Refresh();
};
}
//---------------------------------------------------------------------------
void __fastcall TMain_Form::Refresh(void)
{
FileNameStatusBar->SimpleText="";
Progress_Status_Bar->Panels->Items[0]->Text=0;
Progress_Status_Bar->Panels->Items[1]->Text=0;
Progress_Status_Bar->Panels->Items[2]->Text="";
Main_Form->Caption=Str->Get(0)+SJF->Log->DirectoryName;
Application->Title=Str->Get(0)+SJF->Log->DirectoryName;
Start_Stop->Caption=Str->Get(4);
Browse->Caption=Str->Get(5);
Option->Caption=Str->Get(6);
Help->Caption=Str->Get(7);
Exit->Caption=Str->Get(8);
DeleteToRecycleBin->Caption=Str->Get(9);
SubDirectories->Caption=Str->Get(10);
Language->Caption=Str->Get(11);
CheckOnDefect->Caption=Str->Get(12);
AutoDeleteDefect->Caption=Str->Get(13);
AutoDeleteEqual->Caption=Str->Get(16);
CheckOnEquality->Caption=Str->Get(14);
RateOfDifference->Caption=Str->Get(15);
FullPicture->Caption=Str->Get(17);
SizeControl->Caption=Str->Get(18);
English->Caption=Str->Get(19);
Russian->Caption=Str->Get(20);
DNone->Caption=Str->Get(21);
DSmall->Caption=Str->Get(22);
DMiddle->Caption=Str->Get(23);
DBig->Caption=Str->Get(24);
DVeryBig->Caption=Str->Get(25);
About->Caption=Str->Get(27);
DefaultOption->Caption=Str->Get(34);
};
//---------------------------------------------------------------------------

void __fastcall TMain_Form::AboutClick(TObject *Sender)
{
/*AnsiString temp="";
if(SJF->Log->Language=="English")
{
 temp=AnsiString(" AntiDupl (Version 1.17)\n")+
      AnsiString("written in 2002-2005 by\n")+
      AnsiString("      Yermolayev Ihar\n")+
      AnsiString("       Minsk, Belarus.");
};
if(SJF->Log->Language=="Russian")
{
 temp=AnsiString("AntiDupl (������ 1.17)\n")+
      AnsiString("�������� � 2002-2005\n")+
      AnsiString("���������� ������\n")+
      AnsiString("    �����, ��������.");
};
Application->MessageBox(temp.c_str(),"AntiDupl",MB_OK); */
 About_Dialog->Show(SJF->Log->Language);
}
//---------------------------------------------------------------------------

void __fastcall TMain_Form::DefaultOptionClick(TObject *Sender)
{
DeleteToRecycleBin->Checked=false;
DeleteToRecycleBinClick(Sender);
SubDirectories->Checked=false;
SubDirectoriesClick(Sender);
CheckOnDefect->Checked=false;
CheckOnDefectClick(Sender);
AutoDeleteDefect->Checked=true;
AutoDeleteDefectClick(Sender);
AutoDeleteEqual->Checked=true;
AutoDeleteEqualClick(Sender);
CheckOnEquality->Checked=false;
CheckOnEqualityClick(Sender);
FullPicture->Checked=true;
FullPictureClick(Sender);
SizeControl->Checked=true;
SizeControlClick(Sender);
DMiddle->Checked=false;
DMiddleClick(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TMain_Form::AutoDeleteEqualClick(TObject *Sender)
{
if(AutoDeleteEqual->Checked)
{
 AutoDeleteEqual->Checked=false;
 SJF->Log->AutoDeleteEqual=AutoDeleteEqual->Checked;
}
else
{
 AutoDeleteEqual->Checked=true;
 SJF->Log->AutoDeleteEqual=AutoDeleteEqual->Checked;
};
}
//---------------------------------------------------------------------------



