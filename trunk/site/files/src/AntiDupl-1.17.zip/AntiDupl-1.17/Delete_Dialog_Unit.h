/*
AntiDupl-1.17
Yermalayeu Ihar 
Minsk, Belarus 
2002-2005
http://antidupl.narod.ru
*/
//---------------------------------------------------------------------------

#ifndef Delete_Dialog_UnitH
#define Delete_Dialog_UnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>
#include <jpeg.hpp>
//#include "Option_Unit.h"
//---------------------------------------------------------------------------
const int DelDld_FromBottom_Button = 78;//105;
const int DelDld_FromCenter_Stop = -133;
const int DelDld_FromCenter_Delete = -40;
const int DelDld_FromCenter_Next = 53;
const int DelDld_FromBottom_Image = 86;//113;
const int DelDld_FromRight_Image = 40;
//---------------------------------------------------------------------------
class TSearchLog;
//---------------------------------------------------------------------------
class TDelete_Dialog : public TForm
{
__published:	// IDE-managed Components
        TImage *Image;
        TButton *Delete_Button;
        TButton *Next_Button;
        TButton *Stop_Button;
        TStatusBar *StatusBar1;
        TStatusBar *StatusBar2;
        void __fastcall Delete_ButtonClick(TObject *Sender);
        void __fastcall Next_ButtonClick(TObject *Sender);
        void __fastcall Stop_ButtonClick(TObject *Sender);
        void __fastcall FormResize(TObject *Sender);
private:	// User declarations
        int Answer;
        Graphics::TBitmap *pBitmap;
public:		// User declarations
        int __fastcall Show(TSearchLog *pLog, AnsiString FileName);
        __fastcall TDelete_Dialog(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TDelete_Dialog *Delete_Dialog;
//---------------------------------------------------------------------------
#endif
