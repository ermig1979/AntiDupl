/*
AntiDupl-1.17
Yermalayeu Ihar 
Minsk, Belarus 
2002-2005
http://antidupl.narod.ru
*/
#include <SysUtils.hpp>
#ifndef __Options_Unit_h_
#define __Options_Unit_h_
//---------------------------------------------------------------------------
class TSearchLog
{
 public:
        bool AutoDeleteDefect;
        bool AutoDeleteEqual;
        bool CheckOnDefect;
        bool CheckOnEquality;
        int CompareOder;
        bool DeleteToRecycleBin;
        bool SizeControl;
        bool FullPicture;
        bool SubDirectories;
        AnsiString Language;
        AnsiString DirectoryName;
        int DeleteDialogHeight;
        int DeleteDialogWidth;
        int CompareDialogHeight;
        int CompareDialogWidth;
        __fastcall TSearchLog(void);
        __fastcall ~TSearchLog(void);
        void __fastcall Assign(TSearchLog *temp);
};
//------------------------------------------------------------------------------
class TCaptions
{
private:
        AnsiString *Str;
public:
        TCaptions(void);
        ~TCaptions(void);
        bool Load(AnsiString);
        AnsiString Get(int);
};
//---------------------------------------------------------------------------
#endif //__Options_Unit_h_
