/*
AntiDupl-1.17
Yermalayeu Ihar 
Minsk, Belarus 
2002-2005
http://antidupl.narod.ru
*/
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include <jpeg.hpp>
#include "Compare_Dialog_Unit.h"
#include "Common_Units\Graph_Unit.h"
#include "Main_Form_Unit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TCompare_Dialog *Compare_Dialog;
//---------------------------------------------------------------------------
__fastcall TCompare_Dialog::TCompare_Dialog(TComponent* Owner)
        : TForm(Owner)
{
Answer=0;
}
//---------------------------------------------------------------------------
void __fastcall TCompare_Dialog::Next_ButtonClick(TObject *Sender)
{
Answer=0;
Close();
}
//---------------------------------------------------------------------------

void __fastcall TCompare_Dialog::Delete_Left_ButtonClick(TObject *Sender)
{
Answer=2;
Close();
}
//---------------------------------------------------------------------------

void __fastcall TCompare_Dialog::Delete_Right_ButtonClick(TObject *Sender)
{
Answer=3;
Close();
}
//---------------------------------------------------------------------------
int __fastcall TCompare_Dialog::Show(TSearchLog *pLog, AnsiString LeftFileName, AnsiString RightFileName)
{
 Application->Icon->Handle=LoadIcon(HInstance,"RED");
 Main_Form->Icon->Handle=LoadIcon(HInstance,"RED");
 Answer=0;
 Stop_Button->Caption=Str->Get(3);
 Next_Button->Caption=Str->Get(29);
 Delete_Left_Button->Caption=Str->Get(31);
 Delete_Right_Button->Caption=Str->Get(32);
 Caption=Str->Get(33);
 pLeftBitmap = new Graphics::TBitmap();
 pRightBitmap = new Graphics::TBitmap();
 TJPEGImage *pJpeg = new TJPEGImage();
 StatusBar1->Panels->Items[2]->Text=ExtractFileName(LeftFileName);
 StatusBar1->Panels->Items[5]->Text=ExtractFileName(RightFileName);
 AnsiString temp;
 temp=ExtractFilePath(LeftFileName);
 temp.Delete(1, pLog->DirectoryName.Length());
 StatusBar2->Panels->Items[0]->Text="..."+temp;
 temp=ExtractFilePath(RightFileName);
 temp.Delete(1, pLog->DirectoryName.Length());
 StatusBar2->Panels->Items[1]->Text="..."+temp;

try
{
 pJpeg->LoadFromFile(LeftFileName);
 pJpeg->Grayscale = false;
 StatusBar1->Panels->Items[1]->Text=IntToStr(pJpeg->Width)+"x"+IntToStr(pJpeg->Height);
 pLeftBitmap->Assign(pJpeg);
 int iFileHandle=FileOpen(LeftFileName, fmOpenRead);
 int l=FileSeek(iFileHandle,0,2);
 if(l%1000>=100)StatusBar1->Panels->Items[0]->Text=IntToStr(l/1000)+" "+IntToStr(l%1000)+" B";
 if((l%1000<100)&&(l%1000>=10))StatusBar1->Panels->Items[0]->Text=IntToStr(l/1000)+" 0"+IntToStr(l%1000)+" B";
 if(l%1000<10)StatusBar1->Panels->Items[0]->Text=IntToStr(l/1000)+" 00"+IntToStr(l%1000)+" B";
 FileClose(iFileHandle);
 StretchBitmapToImage(Left_Image, pLeftBitmap);
}
catch(...)
{
 ShowMessage("Can't open file "+LeftFileName);
};
try
{
 pJpeg->LoadFromFile(RightFileName);
 pJpeg->Grayscale = false;
 StatusBar1->Panels->Items[4]->Text=IntToStr(pJpeg->Width)+"x"+IntToStr(pJpeg->Height);
 pRightBitmap->Assign(pJpeg);
 int iFileHandle=FileOpen(RightFileName, fmOpenRead);
 int l=FileSeek(iFileHandle,0,2);
 if(l%1000>=100)StatusBar1->Panels->Items[3]->Text=IntToStr(l/1000)+" "+IntToStr(l%1000)+" B";
 if((l%1000<100)&&(l%1000>=10))StatusBar1->Panels->Items[3]->Text=IntToStr(l/1000)+" 0"+IntToStr(l%1000)+" B";
 if(l%1000<10)StatusBar1->Panels->Items[3]->Text=IntToStr(l/1000)+" 00"+IntToStr(l%1000)+" B";
 FileClose(iFileHandle);
 StretchBitmapToImage(Right_Image, pRightBitmap);
}
catch(...)
{
 ShowMessage("Can't open file "+RightFileName);
};
 Height = pLog->CompareDialogHeight;
 Width = pLog->CompareDialogWidth;
 ShowModal();
 pLog->CompareDialogHeight = Height;
 pLog->CompareDialogWidth = Width;
delete pJpeg;
delete pLeftBitmap;
delete pRightBitmap;
Application->Icon->Handle=LoadIcon(HInstance,"YELLOW");
Main_Form->Icon->Handle=LoadIcon(HInstance,"YELLOW");
return Answer;
};
//---------------------------------------------------------------------------


void __fastcall TCompare_Dialog::Stop_ButtonClick(TObject *Sender)
{
Answer=1;
Close();
}
//---------------------------------------------------------------------------

void __fastcall TCompare_Dialog::FormResize(TObject *Sender)
{
 Stop_Button->Top = ClientHeight - CmpDld_FromBottom_Button;
 Delete_Left_Button->Top = ClientHeight - CmpDld_FromBottom_Button;
 Delete_Right_Button->Top = ClientHeight - CmpDld_FromBottom_Button;
 Next_Button->Top = ClientHeight - CmpDld_FromBottom_Button;

 Stop_Button->Left = Width/2 + CmpDld_FromCenter_Stop;
 Delete_Left_Button->Left = Width/2 + CmpDld_FromCenter_Delete_Left;
 Delete_Right_Button->Left = Width/2 + CmpDld_FromCenter_Delete_Right;
 Next_Button->Left = Width/2 + CmpDld_FromCenter_Next;

 StatusBar1->Panels->Items[2]->Width = Width/2 - 132;
 StatusBar2->Panels->Items[0]->Width = Width/2 - 4;

 Left_Image->Height = ClientHeight - CmpDld_FromBottom_Image;
 Left_Image->Width = Width/2 - CmpDld_FromCenter_Image;
 Left_Image->Picture->Bitmap->Height = ClientHeight - CmpDld_FromBottom_Image;
 Left_Image->Picture->Bitmap->Width = Width/2 - CmpDld_FromCenter_Image;
 StretchBitmapToImage(Left_Image, pLeftBitmap);

 Right_Image->Left = Width/2 + CmpDld_FromCenter_Right_Image;
 Right_Image->Height = ClientHeight - CmpDld_FromBottom_Image;
 Right_Image->Width = Width/2 - CmpDld_FromCenter_Image;
 Right_Image->Picture->Bitmap->Height = ClientHeight - CmpDld_FromBottom_Image;
 Right_Image->Picture->Bitmap->Width = Width/2 - CmpDld_FromCenter_Image;
 StretchBitmapToImage(Right_Image, pRightBitmap);
}
//---------------------------------------------------------------------------

